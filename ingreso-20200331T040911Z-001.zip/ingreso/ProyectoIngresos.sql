-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema ProyectoIngresos
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema ProyectoIngresos
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `ProyectoIngresos` DEFAULT CHARACTER SET utf8 ;
-- -----------------------------------------------------
-- Schema ProyectoIngresos
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema ProyectoIngresos
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `ProyectoIngresos` DEFAULT CHARACTER SET utf8 ;
USE `ProyectoIngresos` ;

-- -----------------------------------------------------
-- Table `ProyectoIngresos`.`CarreraPerteneceDocente`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ProyectoIngresos`.`CarreraPerteneceDocente` (
  `idCarreraDocente` INT NOT NULL AUTO_INCREMENT,
  `Nombre` VARCHAR(45) NULL,
  PRIMARY KEY (`idCarreraDocente`))
ENGINE = InnoDB;

USE `ProyectoIngresos` ;

-- -----------------------------------------------------
-- Table `ProyectoIngresos`.`ingresocarrera`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ProyectoIngresos`.`ingresocarrera` (
  `idingresocarrera` INT(11) NOT NULL AUTO_INCREMENT,
  `Codigo` VARCHAR(45) NULL DEFAULT NULL,
  `NombreCarrera` VARCHAR(45) NULL DEFAULT NULL,
  `Coordinador` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`idingresocarrera`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `ProyectoIngresos`.`ingresodocentes`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ProyectoIngresos`.`ingresodocentes` (
  `idingresodocentes` INT(11) NOT NULL AUTO_INCREMENT,
  `Nombre` VARCHAR(45) NULL DEFAULT NULL,
  `Apellido` VARCHAR(45) NULL DEFAULT NULL,
  `Cedula` VARCHAR(10) NULL DEFAULT NULL,
  `CarreraquePertenece` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`idingresodocentes`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `ProyectoIngresos`.`ingresodocentes_has_ingresocarrera`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ProyectoIngresos`.`ingresodocentes_has_ingresocarrera` (
  `ingresodocentes_idingresodocentes` INT(11) NOT NULL AUTO_INCREMENT,
  `ingresocarrera_idingresocarrera` INT(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`ingresodocentes_idingresodocentes`, `ingresocarrera_idingresocarrera`),
  INDEX `fk_ingresodocentes_has_ingresocarrera_ingresocarrera1_idx` (`ingresocarrera_idingresocarrera` ASC) ,
  INDEX `fk_ingresodocentes_has_ingresocarrera_ingresodocentes_idx` (`ingresodocentes_idingresodocentes` ASC) ,
  CONSTRAINT `fk_ingresodocentes_has_ingresocarrera_ingresocarrera1`
    FOREIGN KEY (`ingresocarrera_idingresocarrera`)
    REFERENCES `ProyectoIngresos`.`ingresocarrera` (`idingresocarrera`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_ingresodocentes_has_ingresocarrera_ingresodocentes`
    FOREIGN KEY (`ingresodocentes_idingresodocentes`)
    REFERENCES `ProyectoIngresos`.`ingresodocentes` (`idingresodocentes`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `ProyectoIngresos`.`Etnias`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ProyectoIngresos`.`Etnias` (
  `idEtnias` INT NOT NULL AUTO_INCREMENT,
  `Nombre` VARCHAR(45) NULL,
  PRIMARY KEY (`idEtnias`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `ProyectoIngresos`.`ingresoestudiantes`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ProyectoIngresos`.`ingresoestudiantes` (
  `idingresoestudiantes` INT(11) NOT NULL AUTO_INCREMENT,
  `Nombres` VARCHAR(45) NULL DEFAULT NULL,
  `Apellidos` VARCHAR(45) NULL DEFAULT NULL,
  `Cedula` VARCHAR(10) NULL DEFAULT NULL,
  `Correo` VARCHAR(45) NULL DEFAULT NULL,
  `NroCelular` VARCHAR(45) NULL DEFAULT NULL,
  `Direccion` VARCHAR(45) NULL DEFAULT NULL,
  `NombreContactoEmergencia` VARCHAR(45) NULL DEFAULT NULL,
  `NroContactoEmergencia` VARCHAR(45) NULL DEFAULT NULL,
  `FechaNacimiento` DATE NULL DEFAULT NULL,
  `Edad` VARCHAR(3) NULL DEFAULT NULL,
  `Nacionalidad` VARCHAR(45) NULL DEFAULT NULL,
  `EstadoCivil` VARCHAR(45) NULL DEFAULT NULL,
  `TieneDiscapacidad` VARCHAR(45) NULL DEFAULT NULL,
  `TipoColegioqueProviene` VARCHAR(45) NULL DEFAULT NULL,
  `TipoBachillerato` VARCHAR(45) NULL DEFAULT NULL,
  `FechaInicio` DATE NULL DEFAULT NULL,
  `FechaMatricula` DATE NULL DEFAULT NULL,
  `Periodo` VARCHAR(45) NULL DEFAULT NULL,
  `TipoMatricula` VARCHAR(45) NULL DEFAULT NULL,
  `NombreCarrera` VARCHAR(45) NULL DEFAULT NULL,
  `TituloqueOtorga` VARCHAR(45) NULL DEFAULT NULL,
  `TipoCarrera` VARCHAR(45) NULL DEFAULT NULL,
  `Modalidad` VARCHAR(45) NULL,
  `Jornada` VARCHAR(45) NULL,
  `Etnias_idEtnias` INT NOT NULL,
  `ingresocarrera_idingresocarrera` INT(11) NOT NULL,
  PRIMARY KEY (`idingresoestudiantes`),
  INDEX `fk_ingresoestudiantes_Etnias1_idx` (`Etnias_idEtnias` ASC),
  INDEX `fk_ingresoestudiantes_ingresocarrera1_idx` (`ingresocarrera_idingresocarrera` ASC) ,
  CONSTRAINT `fk_ingresoestudiantes_Etnias1`
    FOREIGN KEY (`Etnias_idEtnias`)
    REFERENCES `ProyectoIngresos`.`Etnias` (`idEtnias`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_ingresoestudiantes_ingresocarrera1`
    FOREIGN KEY (`ingresocarrera_idingresocarrera`)
    REFERENCES `ProyectoIngresos`.`ingresocarrera` (`idingresocarrera`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

USE `ProyectoIngresos` ;

-- -----------------------------------------------------
-- procedure SP_I_Ingresocarrera
-- -----------------------------------------------------

DELIMITER $$
USE `ProyectoIngresos`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_I_Ingresocarrera`(`pCodigo` VARCHAR(100), `pNombreCarrera` VARCHAR(13), `pCoordinador` VARCHAR(10))
BEGIN		
		INSERT INTO ingresocarrera(Codigo,NombreCarrera,Coordinador)
		VALUES(pCodigo,pNombreCarrera,pCoordinador);
        END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure SP_I_Ingresodocentes
-- -----------------------------------------------------

DELIMITER $$
USE `ProyectoIngresos`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_I_Ingresodocentes`(`pNombre` VARCHAR(45), `pApellido` VARCHAR(13), `pCedula` VARCHAR(10), `pCarreraquePertenece` VARCHAR(45))
BEGIN		
		INSERT INTO ingresodocentes(Nombre,Apellido,Cedula,CarreraquePertenece)
		VALUES(pNombre,pApellido,pCedula,pCarreraquePertenece);
        END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure SP_I_Ingresoestudiantes
-- -----------------------------------------------------

DELIMITER $$
USE `ProyectoIngresos`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_I_Ingresoestudiantes`(`pNombres` VARCHAR(45), `pApellidos` VARCHAR(45),`pCedula` VARCHAR(10), `pCorreo` VARCHAR(45),  `pNroCelular` VARCHAR(10), `pDireccion` VARCHAR(45), `pNombreContactoEmergencia` VARCHAR(45),`pNroContactoEmergencia` varchar(45),`pEtnia`varchar(45), `pFechanacimiento` DATE,`pEdad` VARCHAR(3), `pNacionalidad` VARCHAR(45), `pEstadoCivil` VARCHAR(15), `pTieneDiscapacidad` VARCHAR(45),`pTipoColegioqueProviene` varchar(45),`pTipoBachillerato`varchar(45), 
`pFechaInicio` Date,`pFechaMatricula` Date,`pPeriodo` varchar(45),`pTipoMatricula` varchar(45),`pNombreCarrera` varchar(45),`pTituloqueOtorga` varchar(45),`pTipoCarrera` varchar(45),`pModalidad` varchar(45), `pJornada` VARCHAR(45), `pEtnias_idEtnias` int(11), `pIngresoCarrera_idIngresocarrera` int(11))
BEGIN		
		INSERT INTO ingresoestudiantes(Nombres,Apellidos,Cedula,Correo,NroCelular,Direccion,NombreContactoEmergencia,NroContactoEmergencia,FechaNacimiento,Edad,Nacionalidad,EstadoCivil,
        TieneDiscapacidad,TipoColegioqueProviene,TipoBachillerato,FechaInicio,FechaMatricula,Periodo,TipoMatricula,NombreCarrera,TituloqueOtorga,TipoCarrera,Modalidad,Jornada,Etnias_idEtnias,ingresocarrera_idingresocarrera)
		VALUES(pNombres,pApellidos,pCedula,pCorreo,pNroCelular,pDireccion,pNombreContactoEmergencia,pNroContactoEmergencia,pFechaNacimiento,pEdad,pNacionalidad,pEstadoCivil,
        pTieneDiscapacidad,pTipoColegioqueProviene,pTipoBachillerato,pFechaInicio,pFechaMatricula,pPeriodo,pTipoMatricula,pNombreCarrera,pTituloqueOtorga,pTipoCarrera,pModalidad,pJornada,pEtnias_idEtnias,pingresocarrera_idingresocarrera);
        END$$

DELIMITER ;


-- -----------------------------------------------------
-- procedure SP_S_IngresoCarreraPorParametro
-- -----------------------------------------------------

DELIMITER $$
USE `ProyectoIngresos`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_S_IngresoCarreraPorParametro`(`pcriterio` VARCHAR(20), `pbusqueda` VARCHAR(20))
BEGIN
	IF pcriterio = "id" THEN
		SELECT c.idingresocarrera,c.Codigo,c.NombreCarrera,c.Coordinador FROM ingresocarrera AS c WHERE c.idingresocarrera=pbusqueda;
	ELSEIF pcriterio = "Codigo" THEN
		SELECT c.idingresocarrera,c.Codigo,c.NombreCarrera,c.Coordinador FROM ingresocarrera AS c WHERE c.Codigo LIKE CONCAT("%",pbusqueda,"%");
	ELSEIF pcriterio = "NombreCarrera" THEN
		SELECT c.idingresocarrera,c.Codigo,c.NombreCarrera,c.Coordinador FROM ingresocarrera AS c WHERE c.NombreCarrera LIKE CONCAT("%",pbusqueda,"%");
   ELSEIF pcriterio = "Coordinador" THEN
		SELECT c.idingresocarrera,c.Codigo,c.NombreCarrera,c.Coordinador FROM ingresocarrera AS c WHERE c.Coordinador LIKE CONCAT("%",pbusqueda,"%");
	ELSE
		SELECT c.idingresocarrera,c.Codigo,c.NombreCarrera,c.Coordinador FROM ingresocarrera AS c;
	END IF; 
	END$$

DELIMITER ;
-- -----------------------------------------------------
-- procedure SP_S_IngresoDocentePorParametro
-- -----------------------------------------------------
DELIMITER $$
USE `ProyectoIngresos`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_S_IngresoDocentesPorParametro`(`pcriterio` VARCHAR(20), `pbusqueda` VARCHAR(20))
BEGIN
	IF pcriterio = "idingresodocentes" THEN
		SELECT c.idingresodocentes,c.Nombre,c.Apellido,c.Cedula,c.CarreraquePertenece FROM ingresodocentes AS c WHERE c.idingresodocentes=pbusqueda;
	ELSEIF pcriterio = "Nombre" THEN
		SELECT c.idingresodocentes,c.Nombre,c.Apellido,c.Cedula,c.CarreraquePertenece FROM ingresodocentes AS c WHERE c.Nombre LIKE CONCAT("%",pbusqueda,"%");
	ELSEIF pcriterio = "Apellido" THEN
		SELECT c.idingresodocentes,c.Nombre,c.Apellido,c.Cedula,c.CarreraquePertenece FROM ingresodocentes AS c WHERE c.Apellido LIKE CONCAT("%",pbusqueda,"%");
   ELSEIF pcriterio = "Cedula" THEN
		SELECT c.idingresodocentes,c.Nombre,c.Apellido,c.Cedula,c.CarreraquePertenece FROM ingresocarrera AS c WHERE c.Cedula LIKE CONCAT("%",pbusqueda,"%");
   ELSEIF pcriterio = "CarreraquePertenece" THEN
		SELECT c.idingresodocentes,c.Nombre,c.Apellido,c.Cedula,c.CarreraquePertenece FROM ingresocarrera AS c WHERE c.CarreraquePertenece LIKE CONCAT("%",pbusqueda,"%");
	ELSE
		SELECT c.idingresocarrera,c.Codigo,c.NombreCarrera,c.Coordinador FROM ingresocarrera AS c;
	END IF; 
	END$$

DELIMITER ;


-- -----------------------------------------------------
-- procedure SP_S_IngresoEstudiantesPorParametro
-- -----------------------------------------------------

DELIMITER $$
USE `ProyectoIngresos`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_S_IngresoEstudiantesPorParametro`(`pcriterio` VARCHAR(20), `pbusqueda` VARCHAR(20))
BEGIN
	IF pcriterio = "id" THEN
		SELECT c.Nombres,c.Apellidos,c.Cedula,c.Correo,c.NroCelular,c.Direccion,c.NombreContatoEmergencia,c.NroContactoEmergencia,c.FechaNacimiento,c.Edad,c.Nacionalidad,c.EstadoCivil,c.TieneDiscapacidad,c.TipoColegioqueProviene,c.TipoBachillerato,c.FechaInicio,c.FechaMatricula,c.Periodo,c.TipoMatricula,c.NombreCarrera,c.TituloqueOtorga,c.TipoCarrera,c.Modalidad,c.Jornada,c.Etnias_idEtnias,c.ingresocarrera_idingresocarrera FROM ingresoestudiantes AS c WHERE c.idingresoestudiantes=pbusqueda;
	ELSEIF pcriterio = "Nombres" THEN
		SELECT c.Nombres,c.Apellidos,c.Cedula,c.Correo,c.NroCelular,c.Direccion,c.NombreContatoEmergencia,c.NroContactoEmergencia,c.FechaNacimiento,c.Edad,c.Nacionalidad,c.EstadoCivil,c.TieneDiscapacidad,c.TipoColegioqueProviene,c.TipoBachillerato,c.FechaInicio,c.FechaMatricula,c.Periodo,c.TipoMatricula,c.NombreCarrera,c.TituloqueOtorga,c.TipoCarrera,c.Modalidad,c.Jornada,c.Etnias_idEtnias,c.ingresocarrera_idingresocarrera FROM ingresoestudiantes AS c WHERE c.Nombre LIKE CONCAT("%",pbusqueda,"%");
	ELSEIF pcriterio = "Apellidos" THEN
		SELECT c.Nombres,c.Apellidos,c.Cedula,c.Correo,c.NroCelular,c.Direccion,c.NombreContatoEmergencia,c.NroContactoEmergencia,c.FechaNacimiento,c.Edad,c.Nacionalidad,c.EstadoCivil,c.TieneDiscapacidad,c.TipoColegioqueProviene,c.TipoBachillerato,c.FechaInicio,c.FechaMatricula,c.Periodo,c.TipoMatricula,c.NombreCarrera,c.TituloqueOtorga,c.TipoCarrera,c.Modalidad,c.Jornada,c.Etnias_idEtnias,c.ingresocarrera_idingresocarrera FROM ingresoestudiantes AS c WHERE c.Apellido LIKE CONCAT("%",pbusqueda,"%");
   ELSEIF pcriterio = "Cedula" THEN
		SELECT c.Nombres,c.Apellidos,c.Cedula,c.Correo,c.NroCelular,c.Direccion,c.NombreContatoEmergencia,c.NroContactoEmergencia,c.FechaNacimiento,c.Edad,c.Nacionalidad,c.EstadoCivil,c.TieneDiscapacidad,c.TipoColegioqueProviene,c.TipoBachillerato,c.FechaInicio,c.FechaMatricula,c.Periodo,c.TipoMatricula,c.NombreCarrera,c.TituloqueOtorga,c.TipoCarrera,c.Modalidad,c.Jornada,c.Etnias_idEtnias,c.ingresocarrera_idingresocarrera FROM ingresoestudiantes AS c WHERE c.Correo LIKE CONCAT("%",pbusqueda,"%");
	ELSEIF pcriterio = "Correo" THEN
		SELECT c.Nombres,c.Apellidos,c.Cedula,c.Correo,c.NroCelular,c.Direccion,c.NombreContatoEmergencia,c.NroContactoEmergencia,c.FechaNacimiento,c.Edad,c.Nacionalidad,c.EstadoCivil,c.TieneDiscapacidad,c.TipoColegioqueProviene,c.TipoBachillerato,c.FechaInicio,c.FechaMatricula,c.Periodo,c.TipoMatricula,c.NombreCarrera,c.TituloqueOtorga,c.TipoCarrera,c.Modalidad,c.Jornada,c.Etnias_idEtnias,c.ingresocarrera_idingresocarrera FROM ingresoestudiantess AS c WHERE c.Nro.Celular LIKE CONCAT("%",pbusqueda,"%");
	ELSEIF pcriterio = "NroCelular" THEN
		SELECT c.Nombres,c.Apellidos,c.Cedula,c.Correo,c.NroCelular,c.Direccion,c.NombreContatoEmergencia,c.NroContactoEmergencia,c.FechaNacimiento,c.Edad,c.Nacionalidad,c.EstadoCivil,c.TieneDiscapacidad,c.TipoColegioqueProviene,c.TipoBachillerato,c.FechaInicio,c.FechaMatricula,c.Periodo,c.TipoMatricula,c.NombreCarrera,c.TituloqueOtorga,c.TipoCarrera,c.Modalidad,c.Jornada,c.Etnias_idEtnias,c.ingresocarrera_idingresocarrera FROM ingresoestudiantes AS c WHERE c.Direccion LIKE CONCAT("%",pbusqueda,"%");
	ELSEIF pcriterio = "Direccion" THEN
		SELECT c.Nombres,c.Apellidos,c.Cedula,c.Correo,c.NroCelular,c.Direccion,c.NombreContatoEmergencia,c.NroContactoEmergencia,c.FechaNacimiento,c.Edad,c.Nacionalidad,c.EstadoCivil,c.TieneDiscapacidad,c.TipoColegioqueProviene,c.TipoBachillerato,c.FechaInicio,c.FechaMatricula,c.Periodo,c.TipoMatricula,c.NombreCarrera,c.TituloqueOtorga,c.TipoCarrera,c.Modalidad,c.Jornada,c.Etnias_idEtnias,c.ingresocarrera_idingresocarrera FROM ingresoestudiantes AS c WHERE c.NombreContactoEmergencia LIKE CONCAT("%",pbusqueda,"%");
	ELSEIF pcriterio = "NombreContatoEmergencia" THEN
		SELECT c.Nombres,c.Apellidos,c.Cedula,c.Correo,c.NroCelular,c.Direccion,c.NombreContatoEmergencia,c.NroContactoEmergencia,c.FechaNacimiento,c.Edad,c.Nacionalidad,c.EstadoCivil,c.TieneDiscapacidad,c.TipoColegioqueProviene,c.TipoBachillerato,c.FechaInicio,c.FechaMatricula,c.Periodo,c.TipoMatricula,c.NombreCarrera,c.TituloqueOtorga,c.TipoCarrera,c.Modalidad,c.Jornada,c.Etnias_idEtnias,c.ingresocarrera_idingresocarrera FROM ingresoestudiantes AS c WHERE c.NroContactoemergencia LIKE CONCAT("%",pbusqueda,"%");
	ELSEIF pcriterio = "NroContactoEmergencia" THEN
		SELECT c.Nombres,c.Apellidos,c.Cedula,c.Correo,c.NroCelular,c.Direccion,c.NombreContatoEmergencia,c.NroContactoEmergencia,c.FechaNacimiento,c.Edad,c.Nacionalidad,c.EstadoCivil,c.TieneDiscapacidad,c.TipoColegioqueProviene,c.TipoBachillerato,c.FechaInicio,c.FechaMatricula,c.Periodo,c.TipoMatricula,c.NombreCarrera,c.TituloqueOtorga,c.TipoCarrera,c.Modalidad,c.Jornada,c.Etnias_idEtnias,c.ingresocarrera_idingresocarrera FROM ingresoestudiantes AS c WHERE c.Etnia LIKE CONCAT("%",pbusqueda,"%");
    ELSE
		SELECT c.Nombres,c.Apellidos,c.Cedula,c.Correo,c.NroCelular,c.Direccion,c.NombreContatoEmergencia,c.NroContactoEmergencia,c.FechaNacimiento,c.Edad,c.Nacionalidad,c.EstadoCivil,c.TieneDiscapacidad,c.TipoColegioqueProviene,c.TipoBachillerato,c.FechaInicio,c.FechaMatricula,c.Periodo,c.TipoMatricula,c.NombreCarrera,c.TituloqueOtorga,c.TipoCarrera,c.Modalidad,c.Jornada,c.Etnias_idEtnias,c.ingresocarrera_idingresocarrera FROM ingresoestudiantes AS c;
	END IF; 
	END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure SP_S_Ingresocarrera
-- -----------------------------------------------------

DELIMITER $$
USE `ProyectoIngresos`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_S_Ingresocarrera`()
BEGIN
		SELECT * FROM ingresocarrera;
	END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure SP_S_Ingresodocentes
-- -----------------------------------------------------

DELIMITER $$
USE `ProyectoIngresos`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_S_Ingresodocentes`()
BEGIN
		SELECT * FROM ingresodocentes;
	END$$

DELIMITER ;


-- -----------------------------------------------------
-- procedure SP_S_Ingresoestudiantes
-- -----------------------------------------------------

DELIMITER $$
USE `ProyectoIngresos`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_S_Ingresoestudiantes`()
BEGIN
		SELECT * FROM ingresoestudiantes;
	END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure SP_U_IngresoEstudiates
-- -----------------------------------------------------

DELIMITER $$
USE `ProyectoIngresos`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_U_IngresoEstudiates`(`pNombres` VARCHAR(45), `pApellidos` VARCHAR(45),`pCedula` VARCHAR(10), `pCorreo` VARCHAR(45),  `pNroCelular` VARCHAR(10), `pDireccion` VARCHAR(45), `pNombreContactoEmergencia` VARCHAR(45),`pNroContactoEmergencia` varchar(45),`pFechanacimiento` DATE,`pEdad` VARCHAR(3), `pNacionalidad` VARCHAR(45), `pEstadoCivil` VARCHAR(15), `pTieneDiscapacidad` VARCHAR(45),`pTipoColegioqueProviene` varchar(45),`pTipoBachillerato`varchar(45), 
`pFechaInicio` Date,`pFechaMatricula` Date,`pPeriodo` varchar(45),`pTipoMatricula` varchar(45),`pNombreCarrera` varchar(45),`pTituloqueOtorga` varchar(45),`pTipoCarrera` varchar(45),`pModalidad` varchar(45), `pJornada` VARCHAR(45), `pEtnias_idEtnias` int(11), `pIngresoCarrera_idIngresocarrera` int(11))
BEGIN
		UPDATE ingresoestudiantes SET
			Nombre=pNombre,
			Apellidos=pApellidos,
            Cedula=pCedula,
			Correo=pCorreo,
			NroCelular=pNroCelular,
			Direccion=pDireccion,
			NombreContactoEmergencia=pNombreContactoEmergencia,
            NroContactoEmergencia=pNroContactoEmergencia,
            FechaNacimiento=pFechaNacimiento,
            Edad=pEdad,
            Nacionalidad=pNacionalidad,
            EstadoCivil=pEstadoCivil,
            TieneDiscapacidad=pTieneDiscapacidad,
            TipoColegioqueProviene=pTipoColegioqueProviene,
            TipoBachillerato=pTipoBachillerato,
            FechaInicio=pFechaInicio,
            FechaMatricula=pFechaMatricula,
            Periodo=pPeriodo,
            TipoMatricula=pTipoMatricula,
            NombreCarrera=pNombreCarrera,
            TituloqueOtorga=pTituloqueOtorga,
            TipoCarrera=pTipoCarrera,
            Jornada=pJornada,
            Etnias_idEtnias=pEtnias_idEtnias,
            ingresocarrera_idingresocarrera= pingresoCarrera_idingresocarrera
		WHERE idingresoestudiantes = pidingresoestudiantes;
	END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure SP_U_Ingresocarrera
-- -----------------------------------------------------

DELIMITER $$
USE `ProyectoIngresos`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_U_Ingresocarrera`(`idigresoCarrera` int(11),`pCodigo` VARCHAR(45), `pNombreCarrera` VARCHAR(45), `pCoordinador` VARCHAR(45))
BEGIN
		UPDATE ingresocarrera SET
			Codigo=pCodigo,
			NombreCarrera=pNombreCarrera,
			Coordinador=pCoordinador
			
		WHERE idingresocarrera = pidingresoCarrera;
	END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure SP_U_Ingresodocentes
-- -----------------------------------------------------

DELIMITER $$
USE `ProyectoIngresos`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_U_Ingresodocentes`(`pidingresodocentes` INT(11), `pNombre` VARCHAR(45), `pApellido` VARCHAR(45), `pCedula` VARCHAR(10), `pCarreraquePertenece` VARCHAR(45))
BEGIN
		UPDATE ingresodocentes SET
			Nombre=pNombre,
			Apellido=pApellido,
			Cedula=pCedula,
			CarreraquePertenece=pCarreraquePertenece
		WHERE idingresodocente = pidingresodocente;
	END$$

DELIMITER ;}


DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_S_Etnia`()
BEGIN
		SELECT * FROM etnias;
	END$$
    



DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_I_Etnia`(`pEtnias` VARCHAR(10))
BEGIN
INSERT INTO etnias(Etnias)
		VALUES(pEtnias);
        END$$

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
