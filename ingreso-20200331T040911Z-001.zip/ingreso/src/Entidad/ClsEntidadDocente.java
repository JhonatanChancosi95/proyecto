/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidad;


public class ClsEntidadDocente {
    private String stridingresodocentes;
    private String strNombreDocente;
    private String strApellidoDocente;
    private String strCedulaDocente;
    private String strCarreraquePertenece;

    /**
     * @return the stridingresodocentes
     */
    public String getStridingresodocentes() {
        return stridingresodocentes;
    }

    /**
     * @param stridingresodocentes the stridingresodocentes to set
     */
    public void setStridingresodocentes(String stridingresodocentes) {
        this.stridingresodocentes = stridingresodocentes;
    }

    /**
     * @return the strNombreDocente
     */
    public String getStrNombreDocente() {
        return strNombreDocente;
    }

    /**
     * @param strNombreDocente the strNombreDocente to set
     */
    public void setStrNombreDocente(String strNombreDocente) {
        this.strNombreDocente = strNombreDocente;
    }

    /**
     * @return the strApellidoDocente
     */
    public String getStrApellidoDocente() {
        return strApellidoDocente;
    }

    /**
     * @param strApellidoDocente the strApellidoDocente to set
     */
    public void setStrApellidoDocente(String strApellidoDocente) {
        this.strApellidoDocente = strApellidoDocente;
    }

    /**
     * @return the strCedulaDocente
     */
    public String getStrCedulaDocente() {
        return strCedulaDocente;
    }

    /**
     * @param strCedulaDocente the strCedulaDocente to set
     */
    public void setStrCedulaDocente(String strCedulaDocente) {
        this.strCedulaDocente = strCedulaDocente;
    }

    /**
     * @return the strCarreraquePertenece
     */
    public String getStrCarreraquePertenece() {
        return strCarreraquePertenece;
    }

    /**
     * @param strCarreraquePertenece the strCarreraquePertenece to set
     */
    public void setStrCarreraquePertenece(String strCarreraquePertenece) {
        this.strCarreraquePertenece = strCarreraquePertenece;
    }
}
