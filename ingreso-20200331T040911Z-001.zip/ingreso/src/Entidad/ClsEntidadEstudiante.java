/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidad;

import java.util.Date;

/**
 *
 * @author Sara Cuascota
 */
public class ClsEntidadEstudiante {
    private String stridingresoestudiante;
    private String strNombresEstudiante;
    private String strApellidosEstudiante;
    private String strCedulaEstudiante;
    private String strCorreoEstudiante;
    private String strNroCelularEstudiante;
    private String strDireccionEstudiante;
    private String strNombreContactoEmergenciaEstudiante;
    private String strNroContactoEmergenciaEstudiante;
    private Date strFechaNacimientoEstudiante;
    private String strEdadEstudiante;
    private String strNacionalidadEstudiante;
    private String strEstadoCivilEstudiante;
    private String strTieneDiscapacidadEstudiante;
    private String strTipoColegioqueProvieneEstudiante;
    private String strTipoBachilleratoEstudiante;
    private Date strFechaInicioEstudiante;
    private Date strFechaMatriculaEstudiante;
    private String strPeriodoEstudiante;
    private String strTipoMatriculaEstudiante;
    private String strNombreCarreraEstudiante;
    private String strTituloqueOtorgaEstudiante;
    private String strTipoCarreraEstudiante;
    private String strModalidadEstudiante;
    private String strJornadaEstudiante;
    private String strEtnias_idEtnias;
    private String stringresocarrera_idingresocarrera;

//    public ClsEntidadEstudiante(String stridingresoestudiante, String strNombresEstudiante, String strApellidosEstudiante, String strCedulaEstudiante, String strCorreoEstudiante, String strNroCelularEstudiante, String strDireccionEstudiante, String strNombreContactoEmergenciaEstudiante, String strNroContactoEmergenciaEstudiante, Date strFechaNacimientoEstudiante, String strEdadEstudiante, String strNacionalidadEstudiante, String strEstadoCivilEstudiante, String strTieneDiscapacidadEstudiante, String strTipoColegioqueProvieneEstudiante, String strTipoBachilleratoEstudiante, Date strFechaInicioEstudiante, Date strFechaMatriculaEstudiante, String strPeriodoEstudiante, String strTipoMatriculaEstudiante, String strNombreCarreraEstudiante, String strTituloqueOtorgaEstudiante, String strTipoCarreraEstudiante, String strModalidadEstudiante, String strJornadaEstudiante, String strEtnias_idEtnias, String stringresocarrera_idingresocarrera) {
//        this.stridingresoestudiante = stridingresoestudiante;
//        this.strNombresEstudiante = strNombresEstudiante;
//        this.strApellidosEstudiante = strApellidosEstudiante;
//        this.strCedulaEstudiante = strCedulaEstudiante;
//        this.strCorreoEstudiante = strCorreoEstudiante;
//        this.strNroCelularEstudiante = strNroCelularEstudiante;
//        this.strDireccionEstudiante = strDireccionEstudiante;
//        this.strNombreContactoEmergenciaEstudiante = strNombreContactoEmergenciaEstudiante;
//        this.strNroContactoEmergenciaEstudiante = strNroContactoEmergenciaEstudiante;
//        this.strFechaNacimientoEstudiante = strFechaNacimientoEstudiante;
//        this.strEdadEstudiante = strEdadEstudiante;
//        this.strNacionalidadEstudiante = strNacionalidadEstudiante;
//        this.strEstadoCivilEstudiante = strEstadoCivilEstudiante;
//        this.strTieneDiscapacidadEstudiante = strTieneDiscapacidadEstudiante;
//        this.strTipoColegioqueProvieneEstudiante = strTipoColegioqueProvieneEstudiante;
//        this.strTipoBachilleratoEstudiante = strTipoBachilleratoEstudiante;
//        this.strFechaInicioEstudiante = strFechaInicioEstudiante;
//        this.strFechaMatriculaEstudiante = strFechaMatriculaEstudiante;
//        this.strPeriodoEstudiante = strPeriodoEstudiante;
//        this.strTipoMatriculaEstudiante = strTipoMatriculaEstudiante;
//        this.strNombreCarreraEstudiante = strNombreCarreraEstudiante;
//        this.strTituloqueOtorgaEstudiante = strTituloqueOtorgaEstudiante;
//        this.strTipoCarreraEstudiante = strTipoCarreraEstudiante;
//        this.strModalidadEstudiante = strModalidadEstudiante;
//        this.strJornadaEstudiante = strJornadaEstudiante;
//        this.strEtnias_idEtnias = strEtnias_idEtnias;
//        this.stringresocarrera_idingresocarrera = stringresocarrera_idingresocarrera;
//    }
//
//    public ClsEntidadEstudiante(String strNombresEstudiante, String strApellidosEstudiante, String strCedulaEstudiante, String strCorreoEstudiante, String strNroCelularEstudiante, String strDireccionEstudiante, String strNombreContactoEmergenciaEstudiante, String strNroContactoEmergenciaEstudiante, Date strFechaNacimientoEstudiante, String strEdadEstudiante, String strNacionalidadEstudiante, String strEstadoCivilEstudiante, String strTieneDiscapacidadEstudiante, String strTipoColegioqueProvieneEstudiante, String strTipoBachilleratoEstudiante, Date strFechaInicioEstudiante, Date strFechaMatriculaEstudiante, String strPeriodoEstudiante, String strTipoMatriculaEstudiante, String strNombreCarreraEstudiante, String strTituloqueOtorgaEstudiante, String strTipoCarreraEstudiante, String strModalidadEstudiante, String strJornadaEstudiante, String strEtnias_idEtnias, String stringresocarrera_idingresocarrera) {
//        this.strNombresEstudiante = strNombresEstudiante;
//        this.strApellidosEstudiante = strApellidosEstudiante;
//        this.strCedulaEstudiante = strCedulaEstudiante;
//        this.strCorreoEstudiante = strCorreoEstudiante;
//        this.strNroCelularEstudiante = strNroCelularEstudiante;
//        this.strDireccionEstudiante = strDireccionEstudiante;
//        this.strNombreContactoEmergenciaEstudiante = strNombreContactoEmergenciaEstudiante;
//        this.strNroContactoEmergenciaEstudiante = strNroContactoEmergenciaEstudiante;
//        this.strFechaNacimientoEstudiante = strFechaNacimientoEstudiante;
//        this.strEdadEstudiante = strEdadEstudiante;
//        this.strNacionalidadEstudiante = strNacionalidadEstudiante;
//        this.strEstadoCivilEstudiante = strEstadoCivilEstudiante;
//        this.strTieneDiscapacidadEstudiante = strTieneDiscapacidadEstudiante;
//        this.strTipoColegioqueProvieneEstudiante = strTipoColegioqueProvieneEstudiante;
//        this.strTipoBachilleratoEstudiante = strTipoBachilleratoEstudiante;
//        this.strFechaInicioEstudiante = strFechaInicioEstudiante;
//        this.strFechaMatriculaEstudiante = strFechaMatriculaEstudiante;
//        this.strPeriodoEstudiante = strPeriodoEstudiante;
//        this.strTipoMatriculaEstudiante = strTipoMatriculaEstudiante;
//        this.strNombreCarreraEstudiante = strNombreCarreraEstudiante;
//        this.strTituloqueOtorgaEstudiante = strTituloqueOtorgaEstudiante;
//        this.strTipoCarreraEstudiante = strTipoCarreraEstudiante;
//        this.strModalidadEstudiante = strModalidadEstudiante;
//        this.strJornadaEstudiante = strJornadaEstudiante;
//        this.strEtnias_idEtnias = strEtnias_idEtnias;
//        this.stringresocarrera_idingresocarrera = stringresocarrera_idingresocarrera;
//    }
//
//    public ClsEntidadEstudiante() {
//    }

    public String getStridingresoestudiante() {
        return stridingresoestudiante;
    }

    public void setStridingresoestudiante(String stridingresoestudiante) {
        this.stridingresoestudiante = stridingresoestudiante;
    }

    public String getStrNombresEstudiante() {
        return strNombresEstudiante;
    }

    public void setStrNombresEstudiante(String strNombresEstudiante) {
        this.strNombresEstudiante = strNombresEstudiante;
    }

    public String getStrApellidosEstudiante() {
        return strApellidosEstudiante;
    }

    public void setStrApellidosEstudiante(String strApellidosEstudiante) {
        this.strApellidosEstudiante = strApellidosEstudiante;
    }

    public String getStrCedulaEstudiante() {
        return strCedulaEstudiante;
    }

    public void setStrCedulaEstudiante(String strCedulaEstudiante) {
        this.strCedulaEstudiante = strCedulaEstudiante;
    }

    public String getStrCorreoEstudiante() {
        return strCorreoEstudiante;
    }

    public void setStrCorreoEstudiante(String strCorreoEstudiante) {
        this.strCorreoEstudiante = strCorreoEstudiante;
    }

    public String getStrNroCelularEstudiante() {
        return strNroCelularEstudiante;
    }

    public void setStrNroCelularEstudiante(String strNroCelularEstudiante) {
        this.strNroCelularEstudiante = strNroCelularEstudiante;
    }

    public String getStrDireccionEstudiante() {
        return strDireccionEstudiante;
    }

    public void setStrDireccionEstudiante(String strDireccionEstudiante) {
        this.strDireccionEstudiante = strDireccionEstudiante;
    }

    public String getStrNombreContactoEmergenciaEstudiante() {
        return strNombreContactoEmergenciaEstudiante;
    }

    public void setStrNombreContactoEmergenciaEstudiante(String strNombreContactoEmergenciaEstudiante) {
        this.strNombreContactoEmergenciaEstudiante = strNombreContactoEmergenciaEstudiante;
    }

    public String getStrNroContactoEmergenciaEstudiante() {
        return strNroContactoEmergenciaEstudiante;
    }

    public void setStrNroContactoEmergenciaEstudiante(String strNroContactoEmergenciaEstudiante) {
        this.strNroContactoEmergenciaEstudiante = strNroContactoEmergenciaEstudiante;
    }

    public Date getStrFechaNacimientoEstudiante() {
        return strFechaNacimientoEstudiante;
    }

    public void setStrFechaNacimientoEstudiante(Date strFechaNacimientoEstudiante) {
        this.strFechaNacimientoEstudiante = strFechaNacimientoEstudiante;
    }

    public String getStrEdadEstudiante() {
        return strEdadEstudiante;
    }

    public void setStrEdadEstudiante(String strEdadEstudiante) {
        this.strEdadEstudiante = strEdadEstudiante;
    }

    public String getStrNacionalidadEstudiante() {
        return strNacionalidadEstudiante;
    }

    public void setStrNacionalidadEstudiante(String strNacionalidadEstudiante) {
        this.strNacionalidadEstudiante = strNacionalidadEstudiante;
    }

    public String getStrEstadoCivilEstudiante() {
        return strEstadoCivilEstudiante;
    }

    public void setStrEstadoCivilEstudiante(String strEstadoCivilEstudiante) {
        this.strEstadoCivilEstudiante = strEstadoCivilEstudiante;
    }

    public String getStrTieneDiscapacidadEstudiante() {
        return strTieneDiscapacidadEstudiante;
    }

    public void setStrTieneDiscapacidadEstudiante(String strTieneDiscapacidadEstudiante) {
        this.strTieneDiscapacidadEstudiante = strTieneDiscapacidadEstudiante;
    }

    public String getStrTipoColegioqueProvieneEstudiante() {
        return strTipoColegioqueProvieneEstudiante;
    }

    public void setStrTipoColegioqueProvieneEstudiante(String strTipoColegioqueProvieneEstudiante) {
        this.strTipoColegioqueProvieneEstudiante = strTipoColegioqueProvieneEstudiante;
    }

    public String getStrTipoBachilleratoEstudiante() {
        return strTipoBachilleratoEstudiante;
    }

    public void setStrTipoBachilleratoEstudiante(String strTipoBachilleratoEstudiante) {
        this.strTipoBachilleratoEstudiante = strTipoBachilleratoEstudiante;
    }

    public Date getStrFechaInicioEstudiante() {
        return strFechaInicioEstudiante;
    }

    public void setStrFechaInicioEstudiante(Date strFechaInicioEstudiante) {
        this.strFechaInicioEstudiante = strFechaInicioEstudiante;
    }

    public Date getStrFechaMatriculaEstudiante() {
        return strFechaMatriculaEstudiante;
    }

    public void setStrFechaMatriculaEstudiante(Date strFechaMatriculaEstudiante) {
        this.strFechaMatriculaEstudiante = strFechaMatriculaEstudiante;
    }

    public String getStrPeriodoEstudiante() {
        return strPeriodoEstudiante;
    }

    public void setStrPeriodoEstudiante(String strPeriodoEstudiante) {
        this.strPeriodoEstudiante = strPeriodoEstudiante;
    }

    public String getStrTipoMatriculaEstudiante() {
        return strTipoMatriculaEstudiante;
    }

    public void setStrTipoMatriculaEstudiante(String strTipoMatriculaEstudiante) {
        this.strTipoMatriculaEstudiante = strTipoMatriculaEstudiante;
    }

    public String getStrNombreCarreraEstudiante() {
        return strNombreCarreraEstudiante;
    }

    public void setStrNombreCarreraEstudiante(String strNombreCarreraEstudiante) {
        this.strNombreCarreraEstudiante = strNombreCarreraEstudiante;
    }

    public String getStrTituloqueOtorgaEstudiante() {
        return strTituloqueOtorgaEstudiante;
    }

    public void setStrTituloqueOtorgaEstudiante(String strTituloqueOtorgaEstudiante) {
        this.strTituloqueOtorgaEstudiante = strTituloqueOtorgaEstudiante;
    }

    public String getStrTipoCarreraEstudiante() {
        return strTipoCarreraEstudiante;
    }

    public void setStrTipoCarreraEstudiante(String strTipoCarreraEstudiante) {
        this.strTipoCarreraEstudiante = strTipoCarreraEstudiante;
    }

    public String getStrModalidadEstudiante() {
        return strModalidadEstudiante;
    }

    public void setStrModalidadEstudiante(String strModalidadEstudiante) {
        this.strModalidadEstudiante = strModalidadEstudiante;
    }

    public String getStrJornadaEstudiante() {
        return strJornadaEstudiante;
    }

    public void setStrJornadaEstudiante(String strJornadaEstudiante) {
        this.strJornadaEstudiante = strJornadaEstudiante;
    }

    public String getStrEtnias_idEtnias() {
        return strEtnias_idEtnias;
    }

    public void setStrEtnias_idEtnias(String strEtnias_idEtnias) {
        this.strEtnias_idEtnias = strEtnias_idEtnias;
    }

    public String getStringresocarrera_idingresocarrera() {
        return stringresocarrera_idingresocarrera;
    }

    public void setStringresocarrera_idingresocarrera(String strIngresocarrera_idIngresocarrera) {
        this.stringresocarrera_idingresocarrera = stringresocarrera_idingresocarrera;
    }
    
}
