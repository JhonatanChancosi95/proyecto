/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidad;

/**
 *
 * @author Sara Cuascota
 */
public class ClsEntidadCarreraDocente {
   private String stridCarreraDocente;
   private String strNombreCarreraDocente;

    public ClsEntidadCarreraDocente(String stridCarreraDocente, String strNombreCarreraDocente) {
        this.stridCarreraDocente = stridCarreraDocente;
        this.strNombreCarreraDocente = strNombreCarreraDocente;
    }

    /**
     * @return the stridCarreraDocente
     */
    public String getStridCarreraDocente() {
        return stridCarreraDocente;
    }

    /**
     * @param stridCarreraDocente the stridCarreraDocente to set
     */
    public void setStridCarreraDocente(String stridCarreraDocente) {
        this.stridCarreraDocente = stridCarreraDocente;
    }

    /**
     * @return the strNombreCarreraDocente
     */
    public String getStrNombreCarreraDocente() {
        return strNombreCarreraDocente;
    }

    /**
     * @param strNombreCarreraDocente the strNombreCarreraDocente to set
     */
    public void setStrNombreCarreraDocente(String strNombreCarreraDocente) {
        this.strNombreCarreraDocente = strNombreCarreraDocente;
    }
}
