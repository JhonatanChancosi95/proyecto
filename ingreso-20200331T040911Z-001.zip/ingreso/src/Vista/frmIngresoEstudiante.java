
package vista;
import Procedimientos.ClsIngresoEstudiantes;
import Conexion.ClsConexion;
import Entidad.*;
import java.awt.Color;
import java.awt.Component;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
//import java.io.InputStream;
//import java.net.MalformedURLException;
import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;


public class frmIngresoEstudiante extends javax.swing.JInternalFrame {

     private Connection connection=new ClsConexion().getConection();
    String Total;
    String strCodigo;
    String accion;
    int registros;
    String id[]=new String[50];
    static int intContador;
    
    //-----------------------------------------------
    public String codigo;
    static Connection conn=null;
    static ResultSet rs=null;
    DefaultTableModel dtm=new DefaultTableModel();
    String criterio,busqueda;
    public frmIngresoEstudiante() {
        initComponents();
        //COMBOBOX TIPO COLEGIO QUE PROVIENE
        cbxTipoColegio.addItem("Fiscal");
        cbxTipoColegio.addItem("Particular");
        cbxTipoColegio.addItem("Municipal");
        cbxTipoColegio.addItem("Extrangero");
        cbxTipoColegio.addItem("No registra");
         //COMBOBOX TIPO BACHILLERATO
        cbxTipoBachillerato.addItem("Tecnico");
        cbxTipoBachillerato.addItem("Tecnico Productivo");
        cbxTipoBachillerato.addItem("BGU");
        cbxTipoBachillerato.addItem("BI");
         //COMBOBOX PERIODO
        cbxPeriodo.addItem("Primero(Mayo-Oct)");
        cbxPeriodo.addItem("Segundo(Nov-Abril)");
         //COMBOBOX TIPO MATRICULA
        cbxTipoMatricula.addItem("Ordinaria");
        cbxTipoMatricula.addItem("Extraordinaria");
        cbxTipoMatricula.addItem("Especial");
        //COMBOBOX TITULO QUE OTORGA
        cbxTituloOto.addItem("TECNOLO EN DESARROLLO DE SOFTWARE");
        cbxTituloOto.addItem("TECNOLOGO EN ADMINISTRACION ");
        cbxTituloOto.addItem("TECNOLOGO EN DISENIO GRAFICO ");
        cbxTituloOto.addItem("TECNOLOGO EN ANALISIS DE SISTEMAS ");
        cbxTituloOto.addItem("TECNOLOGO EN ADMINISTRACION DE EMPRESAS ");
        cbxTituloOto.addItem("TECNOLOGO EN DISEÑO GRAFICO (ANTIGUA) ");
        //COMBOBOX TIPO CARRERA
        cbxTipoCarrera.addItem("Tecnicatura");
        cbxTipoCarrera.addItem("Tecnologia");
         //COMBOBOX Modalidad
        cbxModalidad.addItem("Presencial");
        cbxModalidad.addItem("Semipresencial");
        cbxModalidad.addItem("Dual");
         //COMBOBOX JORNADA
        cbxJornada.addItem("Matutina");
        cbxJornada.addItem("Vespertina");
        cbxJornada.addItem("Nocturna");
        cbxJornada.addItem("Intensiva");
        //COMBOBOX FK_CARRERA
        cbxFk_Carrera.addItem("Desarrollo de Software");
        cbxFk_Carrera.addItem("Administracion");
        cbxFk_Carrera.addItem("Disenio Grafico Re");
        cbxFk_Carrera.addItem("Analisis en Sistemas");
        cbxFk_Carrera.addItem("Administracion de Empresas");
        cbxFk_Carrera.addItem("Disenio Grafico");
         //COMBOBOX FK_ETNIA
        cbxFk_Etnia.addItem("Quichuas");
        cbxFk_Etnia.addItem("Montubios");
        cbxFk_Etnia.addItem("Shuar");
        cbxFk_Etnia.addItem("Salasacas");
        cbxFk_Etnia.addItem("Saraguros");
        cbxFk_Etnia.addItem("Caniaris");
        cbxFk_Etnia.addItem("Tsachilas");
        
         tabEstudiante.setIconAt(tabEstudiante.indexOfComponent(pBuscar), new ImageIcon("src/iconos/busca_p1.png"));
        tabEstudiante.setIconAt(tabEstudiante.indexOfComponent(pNuevo), new ImageIcon("src/iconos/nuevo1.png"));
        buttonGroup1.add(rbtnidestudiante);
        buttonGroup1.add(rbtnNombre);
        buttonGroup1.add(rbtnApellido);
        buttonGroup1.add(rbtnCedula);
        
        mirar();
        actualizarTabla();
        //---------------------ANCHO Y ALTO DEL FORM----------------------
        this.setSize(707, 426);
        CrearTabla();
        CantidadTotal();
    }
    void CrearTabla(){
   //--------------------PRESENTACION DE JTABLE----------------------
      
        TableCellRenderer render = new DefaultTableCellRenderer() { 

            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) { 
                //aqui obtengo el render de la calse superior 
                JLabel l = (JLabel)super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column); 
                //Determinar Alineaciones   
                    if(column==0 || column==2 || column==3 || column==5){
                        l.setHorizontalAlignment(SwingConstants.CENTER); 
                    }else{
                        l.setHorizontalAlignment(SwingConstants.LEFT);
                    }

                //Colores en Jtable        
                if (isSelected) {
                    l.setBackground(new Color(203, 159, 41));
                    //l.setBackground(new Color(168, 198, 238));
                    l.setForeground(Color.WHITE); 
                }else{
                    l.setForeground(Color.BLACK);
                    if (row % 2 == 0) {
                        l.setBackground(Color.WHITE);
                    } else {
                        //l.setBackground(new Color(232, 232, 232));
                        l.setBackground(new Color(254, 227, 152));
                    }
                }         
                return l; 
            } 
        }; 
        
        //Agregar Render
        for (int i=0;i<tblEstudiante.getColumnCount();i++){
            tblEstudiante.getColumnModel().getColumn(i).setCellRenderer(render);
        }
      
        //Activar ScrollBar
        tblEstudiante.setAutoResizeMode(tblEstudiante.AUTO_RESIZE_OFF);

        //Anchos de cada columna
        int[] anchos = {50,200,80,80,150,80,200,100,100,100,100,100,100
        ,100,100,100,100,100,100,100,100,100,100,100,100,100,100};
//        JOptionPane.showMessageDialog(null,tblEstudiante.getColumnCount());
        for(int i = 0; i < tblEstudiante.getColumnCount(); i++) {
            tblEstudiante.getColumnModel().getColumn(i).setPreferredWidth(anchos[i]);
        }
    }
     void CantidadTotal(){
       Total= String.valueOf(tblEstudiante.getRowCount());   
       lblEstado.setText("Se cargaron " + Total + " registros");      
   }
   void limpiarCampos(){
       txtId_usuario.setText("");
       txtNombre.setText("");
       txtApellido.setText("");
       txtCedula.setText("");
       txtNroCelular.setText("");
       txtCorreo.setText("");
       txtDireccion.setText("");
       txtNombreEmergencia.setText("");
       txtNroEmergencia.setText("");
       txtFechaNacimiento.setDateFormatString(null);
       txtEdad.setText("");
       txtNacionalidad.setText("");
       txtEstadoCivil.setText("");
       txtDiscapacidad.setText("");
       txtColegioPro.setText("");
       txtTipoBa.setText("");
       txtFechaInicio.setDateFormatString(null);
       txtFechaMatricula.setDateFormatString(null);
       txtPeriodo.setText("");
       txtTipoMatri.setText("");
       txtTituloOto.setText("");
       txtTipoCarrera.setText("");
       txtModalidad.setText("");
       txtJornada.setText("");
       txtFk_Carrera.setText("");
       txtFk_Etnia.setText("");
       
       rbtnidestudiante.setSelected(false);
       rbtnNombre.setSelected(false);
       rbtnApellido.setSelected(false);
       rbtnCedula.setSelected(false);
       txtBusqueda.setText("");
   }
       
   void mirar(){
       tblEstudiante.setEnabled(true);
       btnNuevo.setEnabled(true);
       btnModificar.setEnabled(true);
       btnGuardar.setEnabled(false);
       btnCancelar.setEnabled(false);
       btnSalir.setEnabled(true);
        
       txtNombre.setEnabled(false);
       txtApellido.setEnabled(false);
       txtCedula.setEnabled(false);
       txtNroCelular.setEnabled(false);
       txtCorreo.setEnabled(false);
       txtDireccion.setEnabled(false); 
       txtNombreEmergencia.setEnabled(false);
       txtNroEmergencia.setEnabled(false);
       txtFechaNacimiento.setEnabled(false); 
       txtEdad.setEnabled(false);
       txtNacionalidad.setEnabled(false);
       txtEstadoCivil.setEnabled(false);
       txtDiscapacidad.setEnabled(false);
       txtColegioPro.setEnabled(false);
       txtTipoBa.setEnabled(false);
       txtFechaInicio.setEnabled(false);
       txtFechaMatricula.setEnabled(false); 
       txtPeriodo.setEnabled(false);
       txtJornada.setEnabled(false);
       txtFk_Carrera.setEnabled(false);
       txtFk_Etnia.setEnabled(false);
       txtNombre.requestFocus();
   }
   
   void modificar(){
       tblEstudiante.setEnabled(false);
       btnNuevo.setEnabled(false);
       btnModificar.setEnabled(false);
       btnGuardar.setEnabled(true);
       btnCancelar.setEnabled(true);
       btnSalir.setEnabled(false);
        
       txtNombre.setEnabled(true);
       txtApellido.setEnabled(true);
       txtCedula.setEnabled(true);
       txtNroCelular.setEnabled(true);
       txtCorreo.setEnabled(true);
       txtDireccion.setEnabled(true); 
       txtNombreEmergencia.setEnabled(true);
       txtNroEmergencia.setEnabled(true);
       txtFechaNacimiento.setEnabled(true); 
       txtEdad.setEnabled(true);
       txtNacionalidad.setEnabled(true);
       txtEstadoCivil.setEnabled(true);
       txtDiscapacidad.setEnabled(true);
       txtColegioPro.setEnabled(true);
       txtTipoBa.setEnabled(true);
       txtFechaInicio.setEnabled(true);
       txtFechaMatricula.setEnabled(true); 
       txtPeriodo.setEnabled(true);
       txtJornada.setEnabled(true);
       txtFk_Carrera.setEnabled(true);
       txtFk_Etnia.setEnabled(true);
       txtNombre.requestFocus();
   }
   
   
    void actualizarTabla(){
       String titulos[]={"idingresoestudiantes","Nombres","Apellidos","Cedula","Correo","NroCelular","Direccion","NombreContactoEmergencia","NroContactoEmergencia","FechaNacimiento","Edad","Nacionalidad","EstadoCivil","TieneDiscapacidad","TipoColegioqueProviene",
           "TipoBachillerato","FechaInicio","FechaMatricula","Periodo","TipoCarrera","TituloqueOtorga","TipoCarrera","Modalidad","Jornada","Etnias_idEtnias","ingresocarrera_idingresocarrera"};
              
     ClsIngresoEstudiantes estudiantes=new ClsIngresoEstudiantes();
       ArrayList<ClsEntidadEstudiante> estudiante=estudiantes.listarEstudiantes();
       Iterator iterator=estudiante.iterator();
       DefaultTableModel defaultTableModel=new DefaultTableModel(null,titulos);
       
       String fila[]=new String[26];
        SimpleDateFormat sdf =new  SimpleDateFormat("yyyy/MM/dd");
  
       while(iterator.hasNext()){
           ClsEntidadEstudiante Estudiante=new ClsEntidadEstudiante();
           Estudiante=(ClsEntidadEstudiante) iterator.next();
           fila[0]=Estudiante.getStridingresoestudiante();
           fila[1]=Estudiante.getStrNombresEstudiante();       
           fila[2]=Estudiante.getStrApellidosEstudiante();
           fila[3]=Estudiante.getStrCedulaEstudiante();
           fila[4]=Estudiante.getStrCorreoEstudiante();
           fila[5]=Estudiante.getStrNroCelularEstudiante();
           fila[6]=Estudiante.getStrNombreContactoEmergenciaEstudiante();
           fila[7]=Estudiante.getStrNroContactoEmergenciaEstudiante();
//           fila[8]=sdf.format(Estudiante.getStrFechaNacimientoEstudiante());
           fila[9]=Estudiante.getStrEdadEstudiante();
           fila[10]=Estudiante.getStrNacionalidadEstudiante();
           fila[11]=Estudiante.getStrEstadoCivilEstudiante();
           fila[12]=Estudiante.getStrTieneDiscapacidadEstudiante();
           fila[13]=Estudiante.getStrTipoColegioqueProvieneEstudiante();
           fila[14]=Estudiante.getStrTipoBachilleratoEstudiante();
           fila[15]=sdf.format(Estudiante.getStrFechaInicioEstudiante());
           fila[16]=sdf.format(Estudiante.getStrFechaMatriculaEstudiante());
           fila[17]=Estudiante.getStrPeriodoEstudiante();
           fila[18]=Estudiante.getStrTipoMatriculaEstudiante();
           fila[19]=Estudiante.getStrTituloqueOtorgaEstudiante();
           fila[20]=Estudiante.getStrTipoCarreraEstudiante();
           fila[21]=Estudiante.getStrModalidadEstudiante();
           fila[22]=Estudiante.getStrJornadaEstudiante();
           fila[23]=Estudiante.getStrEtnias_idEtnias();
           fila[24]=Estudiante.getStringresocarrera_idingresocarrera();

           defaultTableModel.addRow(fila);               
       }
       tblEstudiante.setModel(defaultTableModel);
   }
   void BuscarEstudiante(){
        String titulos[]={"idingresoestudiantes","Nombres","Apellidos","Cedula","Correo","NroCelular","Direccion","NombreContactoEmergencia","NroContactoEmergencia","FechaNacimiento","Edad","Nacionalidad",
            "EstadoCivil","TieneDiscapacidad","TipoColegioqueProviene","TipoBachillerato","FechaInicio","FechaMatricula","Periodo","TipoCarrera","TituloqueOtorga","TipoCarrera","Modalidad","Jornada","Etnias_idEtnias","ingresocarrera_idingresocarrera"};
        dtm.setColumnIdentifiers(titulos);
        
        ClsIngresoEstudiantes categoria=new ClsIngresoEstudiantes();
        busqueda=txtBusqueda.getText();
        if(rbtnidestudiante.isSelected()){
            criterio="ID ";
        }else if(rbtnNombre.isSelected()){
            criterio="Nombre";
        }else if(rbtnApellido.isSelected()){
            criterio="Apellido";
        }else if(rbtnCedula.isSelected()){
            criterio="Cedula";
        }
        try{
            rs=categoria.listarEstudiantePorParametro(criterio,busqueda);
            boolean encuentra=false;
            String Datos[]=new String[26];
            int f,i;
            f=dtm.getRowCount();
            if(f>0){
                for(i=0;i<f;i++){
                    dtm.removeRow(0);
                }
            }
            while(rs.next()){
                Datos[0]=(String) rs.getString(1);
                Datos[1]=(String) rs.getString(2);
                Datos[2]=(String) rs.getString(3);
                Datos[3]=(String) rs.getString(4);
                Datos[4]=(String) rs.getString(5);
                Datos[5]=(String) rs.getString(6);
                Datos[6]=(String) rs.getString(7);
                Datos[7]=(String) rs.getString(8);
                Datos[8]=(String) rs.getString(9);
                Datos[9]=(String) rs.getString(10);
                Datos[10]=(String) rs.getString(11);
                Datos[11]=(String) rs.getString(12);
                Datos[12]=(String) rs.getString(13);
                Datos[13]=(String) rs.getString(14);
                Datos[14]=(String) rs.getString(15);
                Datos[15]=(String) rs.getString(16);
                Datos[16]=(String) rs.getString(17);
                Datos[17]=(String) rs.getString(18);
                Datos[18]=(String) rs.getString(19);
                Datos[19]=(String) rs.getString(20);
                Datos[20]=(String) rs.getString(21);
                Datos[21]=(String) rs.getString(22);
                Datos[22]=(String) rs.getString(23);
                Datos[23]=(String) rs.getString(24);
                Datos[24]=(String) rs.getString(25);
                Datos[25]=(String) rs.getString(26);
                dtm.addRow(Datos);
                encuentra=true;

            }
            if(encuentra=false){
                JOptionPane.showMessageDialog(null, "¡No se encuentra!");
            }

        }catch(Exception ex){
            ex.printStackTrace();
        }
        tblEstudiante.setModel(dtm);
    }
    void listardatos(){
        String estado;
        DefaultTableModel defaultTableModel=new DefaultTableModel();
        if(registros==-1){
            JOptionPane.showMessageDialog(null,"Se debe seleccionar un registro");
        }else{
            defaultTableModel=(DefaultTableModel) tblEstudiante.getModel();
            //strCodigo=((String) defaultTableModel.getValueAt(registros,0));
            txtId_usuario.setText((String)defaultTableModel.getValueAt(registros,0));
            txtNombre.setText((String)defaultTableModel.getValueAt(registros,1));
            txtApellido.setText((String)defaultTableModel.getValueAt(registros,2));
            txtCorreo.setText((String)defaultTableModel.getValueAt(registros,3));
            txtDireccion.setText((String)defaultTableModel.getValueAt(registros,4));
            txtNroCelular.setText((String)defaultTableModel.getValueAt(registros,5));
            txtNombreEmergencia.setText((String)defaultTableModel.getValueAt(registros,6));
            txtNroEmergencia.setText((String)defaultTableModel.getValueAt(registros,7));
            txtFechaNacimiento.setDateFormatString((String)defaultTableModel.getValueAt(registros,8));
            txtEdad.setText((String)defaultTableModel.getValueAt(registros,9));
            txtNacionalidad.setText((String)defaultTableModel.getValueAt(registros,10));
            txtEstadoCivil.setText((String)defaultTableModel.getValueAt(registros,11));
            txtDiscapacidad.setText((String)defaultTableModel.getValueAt(registros,12));
            txtColegioPro.setText((String)defaultTableModel.getValueAt(registros,13));
            txtTipoBa.setText((String)defaultTableModel.getValueAt(registros,14)); 
            txtFechaInicio.setDateFormatString((String)defaultTableModel.getValueAt(registros,15));
            txtFechaMatricula.setDateFormatString((String)defaultTableModel.getValueAt(registros,16));
            txtPeriodo.setText((String)defaultTableModel.getValueAt(registros,17));
            txtTipoMatri.setText((String)defaultTableModel.getValueAt(registros,18));
            txtTituloOto.setText((String)defaultTableModel.getValueAt(registros,19));
            txtTipoCarrera.setText((String)defaultTableModel.getValueAt(registros,20));
            txtModalidad.setText((String)defaultTableModel.getValueAt(registros,21));
            txtJornada.setText((String)defaultTableModel.getValueAt(registros,22));
            txtFk_Carrera.setText((String)defaultTableModel.getValueAt(registros,23));
            txtFk_Etnia.setText((String)defaultTableModel.getValueAt(registros,24));
            tblEstudiante.setRowSelectionInterval(registros,registros);
        }
    
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        btnNuevo = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabEstudiante = new javax.swing.JTabbedPane();
        pBuscar = new javax.swing.JPanel();
        rbtnidestudiante = new javax.swing.JRadioButton();
        rbtnApellido = new javax.swing.JRadioButton();
        rbtnNombre = new javax.swing.JRadioButton();
        rbtnCedula = new javax.swing.JRadioButton();
        lblBusqueda = new javax.swing.JLabel();
        txtBusqueda = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblEstudiante = new javax.swing.JTable();
        lblEstado = new javax.swing.JLabel();
        pNuevo = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        txtId_usuario = new javax.swing.JTextField();
        txtNombre = new javax.swing.JTextField();
        txtApellido = new javax.swing.JTextField();
        txtCedula = new javax.swing.JTextField();
        txtNroCelular = new javax.swing.JTextField();
        txtCorreo = new javax.swing.JTextField();
        txtDireccion = new javax.swing.JTextField();
        txtNombreEmergencia = new javax.swing.JTextField();
        txtNroEmergencia = new javax.swing.JTextField();
        cbxFk_Etnia = new javax.swing.JComboBox<>();
        btnEtnia = new javax.swing.JButton();
        txtEdad = new javax.swing.JTextField();
        txtNacionalidad = new javax.swing.JTextField();
        txtEstadoCivil = new javax.swing.JTextField();
        rbtnDiscapacidad = new javax.swing.JRadioButton();
        rbtnNoDiscapacidad = new javax.swing.JRadioButton();
        cbxTipoColegio = new javax.swing.JComboBox<>();
        cbxTipoBachillerato = new javax.swing.JComboBox<>();
        cbxPeriodo = new javax.swing.JComboBox<>();
        cbxTipoMatricula = new javax.swing.JComboBox<>();
        cbxTituloOto = new javax.swing.JComboBox<>();
        cbxTipoCarrera = new javax.swing.JComboBox<>();
        cbxModalidad = new javax.swing.JComboBox<>();
        cbxJornada = new javax.swing.JComboBox<>();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        txtFechaNacimiento = new com.toedter.calendar.JDateChooser();
        txtFechaInicio = new com.toedter.calendar.JDateChooser();
        txtFechaMatricula = new com.toedter.calendar.JDateChooser();
        txtFk_Etnia = new javax.swing.JTextField();
        txtJornada = new javax.swing.JTextField();
        txtModalidad = new javax.swing.JTextField();
        txtTipoCarrera = new javax.swing.JTextField();
        txtTituloOto = new javax.swing.JTextField();
        txtTipoMatri = new javax.swing.JTextField();
        txtPeriodo = new javax.swing.JTextField();
        txtColegioPro = new javax.swing.JTextField();
        txtTipoBa = new javax.swing.JTextField();
        cbxFk_Carrera = new javax.swing.JComboBox<>();
        txtFk_Carrera = new javax.swing.JTextField();
        txtDiscapacidad = new javax.swing.JTextField();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnNuevo.setText("Nuevo");
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });
        getContentPane().add(btnNuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 90, 70, -1));

        btnModificar.setText("Modificar");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });
        getContentPane().add(btnModificar, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 150, -1, -1));

        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });
        getContentPane().add(btnGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 120, -1, -1));

        btnCancelar.setText("Cancelar");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });
        getContentPane().add(btnCancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 180, -1, -1));

        btnSalir.setText("Salir");
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });
        getContentPane().add(btnSalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 210, 80, -1));

        jLabel12.setText("Opciones");
        jLabel12.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jLabel12.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 60, 135, 190));

        pBuscar.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        rbtnidestudiante.setText("ID Ingreso estudiante");
        rbtnidestudiante.setOpaque(false);
        rbtnidestudiante.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                rbtnidestudianteStateChanged(evt);
            }
        });
        rbtnidestudiante.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnidestudianteActionPerformed(evt);
            }
        });
        pBuscar.add(rbtnidestudiante, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 55, -1, -1));

        rbtnApellido.setText("Apellidos");
        pBuscar.add(rbtnApellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 55, -1, -1));

        rbtnNombre.setText("Nombres ");
        rbtnNombre.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                rbtnNombreStateChanged(evt);
            }
        });
        pBuscar.add(rbtnNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 55, -1, -1));

        rbtnCedula.setText("Nº de cedula");
        rbtnCedula.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnCedulaActionPerformed(evt);
            }
        });
        pBuscar.add(rbtnCedula, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 55, -1, -1));

        lblBusqueda.setBackground(new java.awt.Color(204, 204, 204));
        lblBusqueda.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lblBusqueda.setText("Criterios de busqueda");
        lblBusqueda.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        lblBusqueda.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        pBuscar.add(lblBusqueda, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 15, 470, 90));

        txtBusqueda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtBusquedaActionPerformed(evt);
            }
        });
        txtBusqueda.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBusquedaKeyReleased(evt);
            }
        });
        pBuscar.add(txtBusqueda, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 111, 300, 30));

        tblEstudiante.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblEstudiante.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblEstudianteMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblEstudiante);

        pBuscar.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 150, -1, 130));
        pBuscar.add(lblEstado, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 380, 280, 20));

        tabEstudiante.addTab("Buscar", pBuscar);

        pNuevo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel8.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jLabel8.setText("id_Ingresoestudiantes");
        pNuevo.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jLabel3.setText("NOMBRES ");
        pNuevo.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 40, -1, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jLabel2.setText("APELLIDOS");
        pNuevo.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, -1, -1));

        jLabel9.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jLabel9.setText("N° CEDULA");
        pNuevo.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, -1, -1));

        jLabel10.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jLabel10.setText("Nro.CELULAR");
        pNuevo.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, -1, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jLabel4.setText("CORREO");
        pNuevo.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, -1, -1));

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel11.setText("DIRECCION");
        pNuevo.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, -1, -1));

        jLabel18.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel18.setText("NOMBRE CONTACTO EMERGENCIA");
        pNuevo.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, -1, -1));

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel14.setText("NºCONTACTO EMERGENCIA");
        pNuevo.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, -1, -1));

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel13.setText("Fk_ETNIA");
        pNuevo.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 760, -1, -1));

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel16.setText("FECH DE NACIMIENTO");
        pNuevo.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 280, -1, -1));

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel17.setText("EDAD");
        pNuevo.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 310, -1, -1));

        jLabel19.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel19.setText("NACIONALIDAD");
        pNuevo.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 340, -1, -1));

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel15.setText("ESTADO CIVIL");
        pNuevo.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 370, -1, -1));

        jLabel20.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel20.setText("TIENE DISCAPCIDAD");
        pNuevo.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 400, -1, -1));

        jLabel22.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel22.setText("TIPO COLEGIOQUE PROVIENE");
        pNuevo.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 430, -1, -1));

        jLabel21.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel21.setText("TIPO BACHILLERATO");
        pNuevo.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 460, -1, -1));

        txtId_usuario.setEditable(false);
        txtId_usuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtId_usuarioActionPerformed(evt);
            }
        });
        pNuevo.add(txtId_usuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 10, 110, -1));
        pNuevo.add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 40, 230, -1));

        txtApellido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtApellidoActionPerformed(evt);
            }
        });
        pNuevo.add(txtApellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 70, 230, -1));
        pNuevo.add(txtCedula, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 100, 140, -1));
        pNuevo.add(txtNroCelular, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 130, 140, -1));

        txtCorreo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCorreoActionPerformed(evt);
            }
        });
        pNuevo.add(txtCorreo, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 160, 230, -1));
        pNuevo.add(txtDireccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 190, 230, -1));
        pNuevo.add(txtNombreEmergencia, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 220, 230, -1));
        pNuevo.add(txtNroEmergencia, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 250, 230, -1));

        cbxFk_Etnia.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SELECCIONAR" }));
        cbxFk_Etnia.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbxFk_EtniaItemStateChanged(evt);
            }
        });
        cbxFk_Etnia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxFk_EtniaActionPerformed(evt);
            }
        });
        pNuevo.add(cbxFk_Etnia, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 760, 100, -1));

        btnEtnia.setText("Nuevo");
        btnEtnia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEtniaActionPerformed(evt);
            }
        });
        pNuevo.add(btnEtnia, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 760, 70, -1));
        pNuevo.add(txtEdad, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 310, 70, -1));
        pNuevo.add(txtNacionalidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 340, 150, -1));
        pNuevo.add(txtEstadoCivil, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 370, 150, -1));

        rbtnDiscapacidad.setText("SI");
        pNuevo.add(rbtnDiscapacidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 400, -1, -1));

        rbtnNoDiscapacidad.setText("NO");
        pNuevo.add(rbtnNoDiscapacidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 400, -1, -1));

        cbxTipoColegio.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SELECCIONAR" }));
        cbxTipoColegio.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbxTipoColegioItemStateChanged(evt);
            }
        });
        pNuevo.add(cbxTipoColegio, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 430, -1, -1));

        cbxTipoBachillerato.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SELECCIONAR", " ", " " }));
        cbxTipoBachillerato.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbxTipoBachilleratoItemStateChanged(evt);
            }
        });
        pNuevo.add(cbxTipoBachillerato, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 460, -1, -1));

        cbxPeriodo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SELECCIONAR", " " }));
        cbxPeriodo.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbxPeriodoItemStateChanged(evt);
            }
        });
        pNuevo.add(cbxPeriodo, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 550, -1, -1));

        cbxTipoMatricula.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SELECCIONAR", " " }));
        cbxTipoMatricula.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbxTipoMatriculaItemStateChanged(evt);
            }
        });
        pNuevo.add(cbxTipoMatricula, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 580, -1, -1));

        cbxTituloOto.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SELECCIONAR", " " }));
        cbxTituloOto.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbxTituloOtoItemStateChanged(evt);
            }
        });
        cbxTituloOto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxTituloOtoActionPerformed(evt);
            }
        });
        pNuevo.add(cbxTituloOto, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 610, -1, -1));

        cbxTipoCarrera.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SELECCIONAR", " " }));
        cbxTipoCarrera.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbxTipoCarreraItemStateChanged(evt);
            }
        });
        pNuevo.add(cbxTipoCarrera, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 640, -1, -1));

        cbxModalidad.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SELECCIONAR", " " }));
        cbxModalidad.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbxModalidadItemStateChanged(evt);
            }
        });
        pNuevo.add(cbxModalidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 670, 100, -1));

        cbxJornada.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SELECCIONAR" }));
        cbxJornada.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbxJornadaItemStateChanged(evt);
            }
        });
        pNuevo.add(cbxJornada, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 700, 100, -1));

        jLabel29.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel29.setText("JORNADA");
        pNuevo.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 700, -1, -1));

        jLabel30.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel30.setText("MODALIDAD");
        pNuevo.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 670, -1, -1));

        jLabel31.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel31.setText("TIPO DE CARRERA");
        pNuevo.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 640, -1, -1));

        jLabel28.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel28.setText("TITULO QUE OTORGA");
        pNuevo.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 610, -1, -1));

        jLabel27.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel27.setText("Fk_CARRERA");
        pNuevo.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 730, -1, -1));

        jLabel26.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel26.setText("TIPO DE MATRICULA");
        pNuevo.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 580, -1, -1));

        jLabel25.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel25.setText("PERIODO");
        pNuevo.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 550, -1, -1));

        jLabel24.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel24.setText("FECHA DE MATRICULA");
        pNuevo.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 520, -1, -1));

        jLabel23.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel23.setText("FECHA INICIO DE CARRERA");
        pNuevo.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 490, -1, -1));
        pNuevo.add(txtFechaNacimiento, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 280, -1, -1));
        pNuevo.add(txtFechaInicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 490, -1, -1));
        pNuevo.add(txtFechaMatricula, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 520, -1, -1));
        pNuevo.add(txtFk_Etnia, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 760, 100, -1));
        pNuevo.add(txtJornada, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 700, 180, -1));
        pNuevo.add(txtModalidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 670, 180, -1));
        pNuevo.add(txtTipoCarrera, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 640, 180, -1));
        pNuevo.add(txtTituloOto, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 610, 180, -1));
        pNuevo.add(txtTipoMatri, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 580, 180, -1));
        pNuevo.add(txtPeriodo, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 550, 180, -1));
        pNuevo.add(txtColegioPro, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 430, 180, -1));
        pNuevo.add(txtTipoBa, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 460, 180, -1));

        cbxFk_Carrera.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SELECCIONAR" }));
        cbxFk_Carrera.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbxFk_CarreraItemStateChanged(evt);
            }
        });
        pNuevo.add(cbxFk_Carrera, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 730, 100, -1));
        pNuevo.add(txtFk_Carrera, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 730, 100, -1));
        pNuevo.add(txtDiscapacidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 400, 40, -1));

        tabEstudiante.addTab("Nuevo/Modificar", pNuevo);

        jScrollPane2.setViewportView(tabEstudiante);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 510, 350));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        accion = "Nuevo";
        modificar();
        limpiarCampos();
        tblEstudiante.setEnabled(false);
        tabEstudiante.setSelectedIndex(tabEstudiante.indexOfComponent(pNuevo));

        // TODO add your handling code here:
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        if (validardatos() == true) {
            if (accion.equals("Nuevo")) {
                ClsIngresoEstudiantes estudiantes = new ClsIngresoEstudiantes();
                ClsEntidadEstudiante estudiante = new ClsEntidadEstudiante();
                estudiante.setStrNombresEstudiante(txtNombre.getText());
                estudiante.setStrApellidosEstudiante(txtApellido.getText());
                estudiante.setStrCedulaEstudiante(txtCedula.getText());
                estudiante.setStrNroCelularEstudiante(txtNroCelular.getText());
                estudiante.setStrDireccionEstudiante(txtDireccion.getText());
                estudiante.setStrCorreoEstudiante(txtCorreo.getText());
                estudiante.setStrNroContactoEmergenciaEstudiante(txtNombreEmergencia.getText());
                estudiante.setStrNroContactoEmergenciaEstudiante(txtNroEmergencia.getText());
                estudiante.setStrFechaNacimientoEstudiante(txtFechaNacimiento.getDate());
                estudiante.setStrEdadEstudiante(txtEdad.getText());
                estudiante.setStrNacionalidadEstudiante( txtNacionalidad.getText());
                estudiante.setStrEstadoCivilEstudiante(txtEstadoCivil.getText());
                estudiante.setStrTieneDiscapacidadEstudiante(txtDiscapacidad.getText());
                estudiante.setStrTipoColegioqueProvieneEstudiante(txtColegioPro.getText());
                estudiante.setStrTipoBachilleratoEstudiante(txtTipoBa.getText());
                estudiante.setStrFechaInicioEstudiante(txtFechaInicio.getDate());
                estudiante.setStrFechaMatriculaEstudiante( txtFechaMatricula.getDate());
                estudiante.setStrPeriodoEstudiante(txtPeriodo.getText());
                estudiante.setStrTipoMatriculaEstudiante(txtTipoMatri.getText());
                estudiante.setStrTituloqueOtorgaEstudiante(txtTituloOto.getText());
                estudiante.setStrModalidadEstudiante(txtModalidad.getText());
                estudiante.setStrJornadaEstudiante(txtJornada.getText());
                estudiante.setStringresocarrera_idingresocarrera(txtFk_Carrera.getText());
                estudiante.setStrEtnias_idEtnias(txtFk_Etnia.getText());
                estudiantes.agregarEstudiante(estudiante);
                actualizarTabla();
                CantidadTotal();
            }
            if (accion.equals("Modificar")) {
                ClsIngresoEstudiantes estudiantes = new ClsIngresoEstudiantes();
                ClsEntidadEstudiante estudiante = new ClsEntidadEstudiante();
                estudiante.setStrNombresEstudiante(txtNombre.getText());
                estudiante.setStrApellidosEstudiante(txtApellido.getText());
                estudiante.setStrCedulaEstudiante(txtCedula.getText());
                estudiante.setStrNroCelularEstudiante(txtNroCelular.getText());
                estudiante.setStrDireccionEstudiante(txtDireccion.getText());
                estudiante.setStrCorreoEstudiante(txtCorreo.getText());
                estudiante.setStrNroContactoEmergenciaEstudiante(txtNombreEmergencia.getText());
                estudiante.setStrNroContactoEmergenciaEstudiante(txtNroEmergencia.getText());
                estudiante.setStrFechaNacimientoEstudiante(txtFechaNacimiento.getDate());
                estudiante.setStrEdadEstudiante(txtEdad.getText());
                estudiante.setStrNacionalidadEstudiante( txtNacionalidad.getText());
                estudiante.setStrEstadoCivilEstudiante(txtEstadoCivil.getText());
                estudiante.setStrTieneDiscapacidadEstudiante(txtDiscapacidad.getText());
                estudiante.setStrTipoColegioqueProvieneEstudiante(txtColegioPro.getText());
                estudiante.setStrTipoBachilleratoEstudiante(txtTipoBa.getText());
                estudiante.setStrFechaInicioEstudiante(txtFechaInicio.getDate());
                estudiante.setStrFechaMatriculaEstudiante( txtFechaMatricula.getDate());
                estudiante.setStrPeriodoEstudiante(txtPeriodo.getText());
                estudiante.setStrTipoMatriculaEstudiante(txtTipoMatri.getText());
                estudiante.setStrTituloqueOtorgaEstudiante(txtTituloOto.getText());
                estudiante.setStrModalidadEstudiante(txtModalidad.getText());
                estudiante.setStrJornadaEstudiante(txtJornada.getText());
                estudiante.setStringresocarrera_idingresocarrera(txtFk_Carrera.getText());
                estudiante.setStrEtnias_idEtnias(txtFk_Etnia.getText());
                estudiantes.modificarEstudiante(strCodigo, estudiante);
                actualizarTabla();
                limpiarCampos();
                modificar();
                CantidadTotal();
            }
            CrearTabla();
            mirar();
            tabEstudiante.setSelectedIndex(tabEstudiante.indexOfComponent(pBuscar));
        }
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        if (tblEstudiante.getSelectedRows().length > 0) {
            accion = "Modificar";
            modificar();
            tabEstudiante.setSelectedIndex(tabEstudiante.indexOfComponent(pNuevo));
        } else {
            JOptionPane.showMessageDialog(null, "¡Se debe seleccionar un registro!");
        }
    }//GEN-LAST:event_btnModificarActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        mirar();
        tabEstudiante.setSelectedIndex(tabEstudiante.indexOfComponent(pBuscar));
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        // TODO add your handling code here:
        this.dispose();
         System.exit(0);
        }
        public boolean validardatos(){
            if (txtNombre.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Ingrese el Nombre");
                txtNombre.requestFocus();
                txtNombre.setBackground(Color.YELLOW);
                return false;

            }else{
                return true;
            }
    }//GEN-LAST:event_btnSalirActionPerformed

    private void rbtnidestudianteStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_rbtnidestudianteStateChanged
        txtBusqueda.setText("");
    }//GEN-LAST:event_rbtnidestudianteStateChanged

    private void rbtnidestudianteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnidestudianteActionPerformed

    }//GEN-LAST:event_rbtnidestudianteActionPerformed

    private void rbtnNombreStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_rbtnNombreStateChanged
        txtBusqueda.setText("");
    }//GEN-LAST:event_rbtnNombreStateChanged

    private void rbtnCedulaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnCedulaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rbtnCedulaActionPerformed

    private void txtBusquedaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtBusquedaActionPerformed

    }//GEN-LAST:event_txtBusquedaActionPerformed

    private void txtBusquedaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBusquedaKeyReleased
        BuscarEstudiante();
        CrearTabla();
        CantidadTotal();
    }//GEN-LAST:event_txtBusquedaKeyReleased

    private void txtApellidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtApellidoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtApellidoActionPerformed

    private void txtCorreoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCorreoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCorreoActionPerformed

    private void btnEtniaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEtniaActionPerformed
        // TODO add your handling code here:
        Vista.Etnia p=new Vista.Etnia();
        this.tabEstudiante.add(p);
        p.show();
    }//GEN-LAST:event_btnEtniaActionPerformed

    private void txtId_usuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtId_usuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtId_usuarioActionPerformed

    private void tblEstudianteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblEstudianteMouseClicked
        // TODO add your handling code here:
        int fila;
        DefaultTableModel defaultTableModel = new DefaultTableModel();
        fila = tblEstudiante.getSelectedRow();

        if (fila == -1){
            JOptionPane.showMessageDialog(null, "Se debe seleccionar un registro");
        }else{
            defaultTableModel = (DefaultTableModel)tblEstudiante.getModel();
//            strCodigo =  ((String) defaultTableModel.getValueAt(fila, 0));
            txtId_usuario.setText((String) defaultTableModel.getValueAt(fila, 0));
            txtNombre.setText((String) defaultTableModel.getValueAt(fila, 1));
            txtApellido.setText((String)defaultTableModel.getValueAt(fila,2));
            txtCedula.setText((String)defaultTableModel.getValueAt(fila,3));
            txtNroCelular.setText((String)defaultTableModel.getValueAt(fila,4));
            txtCorreo.setText((String)defaultTableModel.getValueAt(fila,5));
            txtDireccion.setText((String)defaultTableModel.getValueAt(fila,6));
            txtNombreEmergencia.setText((String) defaultTableModel.getValueAt(fila, 7));
            txtNroEmergencia.setText((String)defaultTableModel.getValueAt(fila,8));
            txtFechaNacimiento.setDateFormatString((String)defaultTableModel.getValueAt(fila,9));
            txtEdad.setText((String)defaultTableModel.getValueAt(fila,10));
            txtNacionalidad.setText((String)defaultTableModel.getValueAt(fila,11));
            txtEstadoCivil.setText((String)defaultTableModel.getValueAt(fila,12));
            txtDiscapacidad.setText((String)defaultTableModel.getValueAt(fila,13));
            txtColegioPro.setText((String)defaultTableModel.getValueAt(fila,14));
            txtTipoBa.setText((String)defaultTableModel.getValueAt(fila,15));
            txtFechaInicio.setDateFormatString((String)defaultTableModel.getValueAt(fila,16));
            txtFechaMatricula.setDateFormatString((String)defaultTableModel.getValueAt(fila,17));
            txtPeriodo.setText((String)defaultTableModel.getValueAt(fila,18));
            txtTipoMatri.setText((String)defaultTableModel.getValueAt(fila,19));
            txtTituloOto.setText((String)defaultTableModel.getValueAt(fila,20));
            txtTipoCarrera.setText((String)defaultTableModel.getValueAt(fila,21));
            txtModalidad.setText((String)defaultTableModel.getValueAt(fila,22));
            txtFk_Carrera.setText((String)defaultTableModel.getValueAt(fila,23));
            txtFk_Etnia.setText((String)defaultTableModel.getValueAt(fila,24));
           
        }
        mirar();
                      
    }//GEN-LAST:event_tblEstudianteMouseClicked

    private void cbxFk_EtniaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxFk_EtniaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbxFk_EtniaActionPerformed

    private void cbxTipoColegioItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbxTipoColegioItemStateChanged
        // TODO add your handling code here:
    String TipoColegio=(String)cbxTipoColegio.getSelectedItem();
    if(TipoColegio.equals("Fiscal"))
    {
        txtColegioPro.setText("Fiscal");
    }
     if(TipoColegio.equals("Particular"))
    {
        txtColegioPro.setText("Particular");
    }
      if(TipoColegio.equals("Municipal"))
    {
        txtColegioPro.setText("Municipal");
    }
       if(TipoColegio.equals("Extrangero"))
    {
        txtColegioPro.setText("Extrangero");
    }
        if(TipoColegio.equals("No registra"))
    {
        txtColegioPro.setText("No registra");
    }
    }//GEN-LAST:event_cbxTipoColegioItemStateChanged

    private void cbxTipoBachilleratoItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbxTipoBachilleratoItemStateChanged
        // TODO add your handling code here:
      String TipoBachillerato=(String)cbxTipoBachillerato.getSelectedItem();
    if(TipoBachillerato.equals("Tecnico"))
    {
        txtTipoBa.setText("Tecnico");
    }
     if(TipoBachillerato.equals("Tecnico Productivo"))
    {
        txtTipoBa.setText("Tecnico Productivo");
    }
      if(TipoBachillerato.equals("BGU"))
    {
        txtTipoBa.setText("BGU");
    }
       if(TipoBachillerato.equals("BI"))
    {
        txtTipoBa.setText("BI");
    }
    }//GEN-LAST:event_cbxTipoBachilleratoItemStateChanged

    private void cbxPeriodoItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbxPeriodoItemStateChanged
        // TODO add your handling code here:
       String Periodo=(String)cbxPeriodo.getSelectedItem();
    if(Periodo.equals("Primero(Mayo-Oct)"))
    {
        txtPeriodo.setText("Primero(Mayo-Oct)");
    }
     if(Periodo.equals("Segundo(Nov-Abril)"))
    {
        txtPeriodo.setText("Segundo(Nov-Abril");
      }
    }//GEN-LAST:event_cbxPeriodoItemStateChanged

    private void cbxTituloOtoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxTituloOtoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbxTituloOtoActionPerformed

    private void cbxTipoMatriculaItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbxTipoMatriculaItemStateChanged
        // TODO add your handling code here:
        String TipoMatricula=(String)cbxTipoMatricula.getSelectedItem();
    if(TipoMatricula.equals("Ordinaria"))
    {
        txtTipoMatri.setText("Ordinaria");
    }
     if(TipoMatricula.equals("Extraordinaria"))
    {
        txtTipoMatri.setText("Extraordinaria");
    }
      if(TipoMatricula.equals("Especial"))
    {
        txtTipoMatri.setText("Especial ");
    }
    }//GEN-LAST:event_cbxTipoMatriculaItemStateChanged

    private void cbxTituloOtoItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbxTituloOtoItemStateChanged
        // TODO add your handling code here:
        String Titulo=(String)cbxTituloOto.getSelectedItem();
    if(Titulo.equals("TECNOLO EN DESARROLLO DE SOFTWARE"))
    {
        txtTituloOto.setText("TECNOLO EN DESARROLLO DE SOFTWARE");
    }
     if(Titulo.equals("TECNOLOGO EN ADMINISTRACION "))
    {
        txtTituloOto.setText("TECNOLOGO EN ADMINISTRACION ");
    }
      if(Titulo.equals("TECNOLOGO EN DISENIO GRAFICO"))
    {
        txtTituloOto.setText("TECNOLOGO EN DISENIO GRAFICO");
    }
       if(Titulo.equals("TECNOLOGO EN ANALISIS DE SISTEMAS"))
    {
        txtTituloOto.setText("TECNOLOGO EN ANALISIS DE SISTEMAS");
    }
        if(Titulo.equals("TECNOLOGO EN ADMINISTRACION DE EMPRESAS"))
    {
        txtTituloOto.setText("TECNOLOGO EN ADMINISTRACION DE EMPRESAS");
    }
         if(Titulo.equals("TECNOLOGO EN DISEÑO GRAFICO (ANTIGUA)"))
    {
        txtTituloOto.setText("TECNOLOGO EN DISEÑO GRAFICO (ANTIGUA)");
    }
    }//GEN-LAST:event_cbxTituloOtoItemStateChanged

    private void cbxTipoCarreraItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbxTipoCarreraItemStateChanged
        // TODO add your handling code here:
          String TipoCarrera=(String)cbxTipoCarrera.getSelectedItem();
    if(TipoCarrera.equals("Tecnicatura"))
    {
        txtTipoCarrera.setText("Tecnicatura");
    }
    if(TipoCarrera.equals("Tecnologia"))
    {
         txtTipoCarrera.setText("Tecnologia");
    }
    }//GEN-LAST:event_cbxTipoCarreraItemStateChanged

    private void cbxModalidadItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbxModalidadItemStateChanged
        // TODO add your handling code here:
         String Modalidad=(String)cbxModalidad.getSelectedItem();
    if(Modalidad.equals("Presencial"))
    {
        txtModalidad.setText("Presencial");
    }
    if(Modalidad.equals("Semipresencial"))
    {
        txtModalidad.setText("Semipresencial");
    }
    if(Modalidad.equals("Dual"))
    {
        txtModalidad.setText("Dual");
    }
    }//GEN-LAST:event_cbxModalidadItemStateChanged

    private void cbxJornadaItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbxJornadaItemStateChanged
        // TODO add your handling code here:
         String Jornada=(String)cbxJornada.getSelectedItem();
    if(Jornada.equals("Matutina"))
    {
        txtJornada.setText("Matutina");
    }
    if(Jornada.equals("Matutina"))
    {
        txtJornada.setText("Matutina");
    }
    if(Jornada.equals("Vespertina"))
    {
        txtJornada.setText("Vespertina");
    }
    if(Jornada.equals("Nocturna"))
    {
        txtJornada.setText("Nocturna");
    }
    }//GEN-LAST:event_cbxJornadaItemStateChanged

    private void cbxFk_CarreraItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbxFk_CarreraItemStateChanged
        // TODO add your handling code here:
        String Fk_Carrera=(String)cbxFk_Carrera.getSelectedItem();
    if(Fk_Carrera.equals("Desarrollo de Software"))
    {
        txtFk_Carrera.setText("1");
    }
    if(Fk_Carrera.equals("Administracion"))
    {
        txtFk_Carrera.setText("2");
    }
    if(Fk_Carrera.equals("Disenio Grafico Re"))
    {
        txtFk_Carrera.setText("3");
    }
    if(Fk_Carrera.equals("Analisis en Sistemas"))
    {
        txtFk_Carrera.setText("4");
    }
    if(Fk_Carrera.equals("Administracion de Empresas"))
    {
        txtFk_Carrera.setText("5");
    }
    if(Fk_Carrera.equals("Disenio Grafico"))
    {
        txtFk_Carrera.setText("6");
    }
    }//GEN-LAST:event_cbxFk_CarreraItemStateChanged

    private void cbxFk_EtniaItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbxFk_EtniaItemStateChanged
        // TODO add your handling code here:
      String Fk_Etnia=(String)cbxFk_Etnia.getSelectedItem();
    if(Fk_Etnia.equals("Quichuas"))
    {
        txtFk_Etnia.setText("1");
    }   
    if(Fk_Etnia.equals("Montubios"))
    {
        txtFk_Etnia.setText("2");
    }
    if(Fk_Etnia.equals("Shuar"))
    {
        txtFk_Etnia.setText("3");
    } 
    if(Fk_Etnia.equals("Salasacas"))
    {
        txtFk_Etnia.setText("4");
    }   
    if(Fk_Etnia.equals("Saraguros"))
    {
        txtFk_Etnia.setText("5");
    } 
    if(Fk_Etnia.equals("Caniaris"))
    {
        txtFk_Etnia.setText("6");
    } 
    if(Fk_Etnia.equals("Tsachilas"))
    {
        txtFk_Etnia.setText("7");
    }   
    }//GEN-LAST:event_cbxFk_EtniaItemStateChanged


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnEtnia;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JButton btnSalir;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<String> cbxFk_Carrera;
    private javax.swing.JComboBox<String> cbxFk_Etnia;
    private javax.swing.JComboBox<String> cbxJornada;
    private javax.swing.JComboBox<String> cbxModalidad;
    private javax.swing.JComboBox<String> cbxPeriodo;
    private javax.swing.JComboBox<String> cbxTipoBachillerato;
    private javax.swing.JComboBox<String> cbxTipoCarrera;
    private javax.swing.JComboBox<String> cbxTipoColegio;
    private javax.swing.JComboBox<String> cbxTipoMatricula;
    private javax.swing.JComboBox<String> cbxTituloOto;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblBusqueda;
    private javax.swing.JLabel lblEstado;
    private javax.swing.JPanel pBuscar;
    private javax.swing.JPanel pNuevo;
    private javax.swing.JRadioButton rbtnApellido;
    private javax.swing.JRadioButton rbtnCedula;
    private javax.swing.JRadioButton rbtnDiscapacidad;
    private javax.swing.JRadioButton rbtnNoDiscapacidad;
    private javax.swing.JRadioButton rbtnNombre;
    private javax.swing.JRadioButton rbtnidestudiante;
    private javax.swing.JTabbedPane tabEstudiante;
    private javax.swing.JTable tblEstudiante;
    private javax.swing.JTextField txtApellido;
    private javax.swing.JTextField txtBusqueda;
    private javax.swing.JTextField txtCedula;
    private javax.swing.JTextField txtColegioPro;
    private javax.swing.JTextField txtCorreo;
    private javax.swing.JTextField txtDireccion;
    private javax.swing.JTextField txtDiscapacidad;
    private javax.swing.JTextField txtEdad;
    private javax.swing.JTextField txtEstadoCivil;
    private com.toedter.calendar.JDateChooser txtFechaInicio;
    private com.toedter.calendar.JDateChooser txtFechaMatricula;
    private com.toedter.calendar.JDateChooser txtFechaNacimiento;
    private javax.swing.JTextField txtFk_Carrera;
    private javax.swing.JTextField txtFk_Etnia;
    private javax.swing.JTextField txtId_usuario;
    private javax.swing.JTextField txtJornada;
    private javax.swing.JTextField txtModalidad;
    private javax.swing.JTextField txtNacionalidad;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtNombreEmergencia;
    private javax.swing.JTextField txtNroCelular;
    private javax.swing.JTextField txtNroEmergencia;
    private javax.swing.JTextField txtPeriodo;
    private javax.swing.JTextField txtTipoBa;
    private javax.swing.JTextField txtTipoCarrera;
    private javax.swing.JTextField txtTipoMatri;
    private javax.swing.JTextField txtTituloOto;
    // End of variables declaration//GEN-END:variables
}
