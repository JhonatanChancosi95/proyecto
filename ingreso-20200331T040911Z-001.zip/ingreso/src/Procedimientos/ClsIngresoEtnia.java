
package Procedimientos;

import Conexion.ClsConexion;
import Entidad.ClsEntidadDocente;
import Entidad.ClsEntidadEtnias;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;


public class ClsIngresoEtnia {
    private Connection connection=new ClsConexion().getConection();
    //--------------------------------------------------------------------------------------------------
    //-----------------------------------------METODOS--------------------------------------------------
    //-------------------------------------------------------------------------------------------------- 
    public void agregarEtnia(ClsEntidadEtnias Etnia){
        try{
            CallableStatement statement=connection.prepareCall("{call SP_I_Etnia(?)}");
            statement.setString("pEtnia",Etnia.getStrNombreEtnias());
            statement.execute();

            JOptionPane.showMessageDialog(null,"¡Etnia Agregada con éxito!","Mensaje del Sistema",1);           

        }catch(SQLException ex){
            
            ex.printStackTrace();
        }
        }
         public ArrayList<ClsEntidadEtnias> listarEtnias(){
        ArrayList<ClsEntidadEtnias> etniasusuarios=new ArrayList<ClsEntidadEtnias>();
        try{
            CallableStatement statement=connection.prepareCall("{call SP_S_Etnia}");
            ResultSet resultSet=statement.executeQuery();
            
            while (resultSet.next()){
                ClsEntidadEtnias etnia=new ClsEntidadEtnias();
                etnia.setStridEtnias(resultSet.getString("idEtnias"));
                etnia.setStrNombreEtnias(resultSet.getString("Nombre"));
                etniasusuarios.add(etnia);
            }
            return etniasusuarios;
         }catch(SQLException ex){
            ex.printStackTrace();
            return null;
        }
    }      
    
}
