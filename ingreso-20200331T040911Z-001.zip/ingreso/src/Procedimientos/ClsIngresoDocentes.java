
package Procedimientos;
import Conexion.*;
import Entidad.*;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class ClsIngresoDocentes {
  private Connection connection=new ClsConexion().getConection();
    //--------------------------------------------------------------------------------------------------
    //-----------------------------------------METODOS--------------------------------------------------
    //-------------------------------------------------------------------------------------------------- 
    public void agregarDocente(ClsEntidadDocente Docente){
        try{
            CallableStatement statement=connection.prepareCall("{call SP_I_Ingresodocentes(?,?,?,?)}");
            statement.setString("pNombre",Docente.getStrNombreDocente());
            statement.setString("pApellido",Docente.getStrApellidoDocente());
            statement.setString("pCedula",Docente.getStrCedulaDocente());
            statement.setString("pCarreraquePertenece",Docente.getStrCarreraquePertenece());
            statement.execute();

            JOptionPane.showMessageDialog(null,"¡Docente Agregado con éxito!","Mensaje del Sistema",1);           

        }catch(SQLException ex){
            ex.printStackTrace();
        }
        
    }    
    public void modificarDocente(String codigo,ClsEntidadDocente Docente){
        try{
            CallableStatement statement=connection.prepareCall("{call SP_U_Ingresodocentes(?,?,?,?)}");
            //statement.setString("pidingresodocentes",codigo);
            statement.setString("pNombre",Docente.getStrNombreDocente());
            statement.setString("pApellido",Docente.getStrApellidoDocente());
            statement.setString("pCedula",Docente.getStrCedulaDocente());
            statement.setString("pCarreraquePertenece", Docente.getStrCarreraquePertenece());
            statement.executeUpdate();
            
        }catch(SQLException ex){
            ex.printStackTrace();
        }
        JOptionPane.showMessageDialog(null,"¡Docente Actualizado!","Mensaje del Sistema",1);
    }
    public ArrayList<ClsEntidadDocente> listarDocente(){
        ArrayList<ClsEntidadDocente> docenteusuarios=new ArrayList<ClsEntidadDocente>();
        try{
            CallableStatement statement=connection.prepareCall("{call SP_S_Ingresodocentes}");
            ResultSet resultSet=statement.executeQuery();
            
            while (resultSet.next()){
                ClsEntidadDocente docente=new ClsEntidadDocente();
                docente.setStridingresodocentes(resultSet.getString("idingresodocentes"));
                docente.setStrNombreDocente(resultSet.getString("Nombre"));
                docente.setStrApellidoDocente(resultSet.getString("Apellido"));
                docente.setStrCedulaDocente(resultSet.getString("Cedula"));
                docente.setStrCarreraquePertenece(resultSet.getString("CarreraquePertenece"));
                docenteusuarios.add(docente);
            }
            return docenteusuarios;
         }catch(SQLException ex){
            ex.printStackTrace();
            return null;
        }
    }      
    public ResultSet listarDocentePorParametro(String criterio, String busqueda) throws Exception{
        ResultSet rs = null;
        try{
            CallableStatement statement = connection.prepareCall("{call SP_S_IngresodocentePorParametro(?,?)}");
            statement.setString("pcriterio", criterio);
            statement.setString("pbusqueda", busqueda);
            rs = statement.executeQuery();
            return rs;
        }catch(SQLException SQLex){
            throw SQLex;            
        }        
    }
    
}
