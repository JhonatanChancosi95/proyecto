
package Procedimientos;
import Conexion.ClsConexion;
import Entidad.ClsEntidadEstudiante;
import Conexion.*;
import Entidad.*;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import java.util.Iterator;

public class ClsIngresoEstudiantes {
    private Connection connection=new ClsConexion().getConection();
    //--------------------------------------------------------------------------------------------------
    //-----------------------------------------METODOS--------------------------------------------------
    //-------------------------------------------------------------------------------------------------- 
    public void agregarEstudiante(ClsEntidadEstudiante Estudiante){
        try{
           CallableStatement statement=connection.prepareCall("{call SP_I_Ingresoestudiantes(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
            statement.setString("pNombres",Estudiante.getStrNombresEstudiante());
            statement.setString("pApellidos",Estudiante.getStrApellidosEstudiante());
            statement.setString("pCedula",Estudiante.getStrCedulaEstudiante());
            statement.setString("pCorreo",Estudiante.getStrCorreoEstudiante());
            statement.setString("NroCelular",Estudiante.getStrNroCelularEstudiante());
            statement.setString("pDireccion",Estudiante.getStrDireccionEstudiante());
            statement.setString("pNombreContactoEmergencia",Estudiante.getStrNombreContactoEmergenciaEstudiante());
            statement.setString("pNroContactoEmergencia",Estudiante.getStrNroContactoEmergenciaEstudiante());        
            statement.setDate("pFechaNacimiento",new java.sql.Date(Estudiante.getStrFechaNacimientoEstudiante().getTime()));
            statement.setString("pEdad",Estudiante.getStrEdadEstudiante());
            statement.setString("pNacionalidad",Estudiante.getStrNacionalidadEstudiante());
            statement.setString("pEstadoCivil",Estudiante.getStrEstadoCivilEstudiante());
            statement.setString("pTieneDiscapacidad",Estudiante.getStrTieneDiscapacidadEstudiante());
            statement.setString("pTipoColegioqueProviene",Estudiante.getStrTipoColegioqueProvieneEstudiante());
            statement.setString("pTipoBachillerato",Estudiante.getStrTipoBachilleratoEstudiante());
            statement.setDate("pFechaInicio",new java.sql.Date(Estudiante.getStrFechaInicioEstudiante().getTime()));
            statement.setDate("pFechaMatricula",new java.sql.Date(Estudiante.getStrFechaMatriculaEstudiante().getTime()));
            statement.setString("pPeriodo",Estudiante.getStrPeriodoEstudiante());
            statement.setString("pTipoMatricula",Estudiante.getStrTipoMatriculaEstudiante());
            statement.setString("pNombreCarrera",Estudiante.getStrNombreCarreraEstudiante());
            statement.setString("pTituloqueOtorga",Estudiante.getStrTituloqueOtorgaEstudiante());
            statement.setString("pTipoCarrera",Estudiante.getStrTipoCarreraEstudiante());
            statement.setString("pModalidad",Estudiante.getStrModalidadEstudiante());
            statement.setString("pJornada",Estudiante.getStrJornadaEstudiante());
            statement.setString("pEtnias_idEtnias",Estudiante.getStrEtnias_idEtnias());
            statement.setString("pingresocarrera_idingresocarrera",Estudiante.getStringresocarrera_idingresocarrera());
           
            statement.execute();

            JOptionPane.showMessageDialog(null,"¡Estudiante Agregado con éxito!","Mensaje del Sistema",1); 
            }catch(SQLException ex){
            ex.printStackTrace();
        }
        }    
    public void modificarEstudiante(String codigo,ClsEntidadEstudiante Estudiante){
        try{
            CallableStatement statement=connection.prepareCall("{call SP_U_Ingresoestudiantes(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
            statement.setString("pidingresoestudiantes",codigo);
           statement.setString("pNombres",Estudiante.getStrNombresEstudiante());
            statement.setString("pApellidos",Estudiante.getStrApellidosEstudiante());
            statement.setString("pCedula",Estudiante.getStrCedulaEstudiante());
            statement.setString("pCorreo",Estudiante.getStrCorreoEstudiante());
            statement.setString("NroCelular",Estudiante.getStrNroCelularEstudiante());
            statement.setString("pDireccion",Estudiante.getStrDireccionEstudiante());
            statement.setString("pNombreContactoEmergencia",Estudiante.getStrNombreContactoEmergenciaEstudiante());
            statement.setString("pNroContactoEmergencia",Estudiante.getStrNroContactoEmergenciaEstudiante());
            statement.setDate("pFechaNacimiento",new java.sql.Date(Estudiante.getStrFechaNacimientoEstudiante().getTime()));
            statement.setString("pEdad",Estudiante.getStrEdadEstudiante());
            statement.setString("pNacionalidad",Estudiante.getStrNacionalidadEstudiante());
            statement.setString("pEstadoCivil",Estudiante.getStrEstadoCivilEstudiante());
            statement.setString("pTieneDiscapacidad",Estudiante.getStrTieneDiscapacidadEstudiante());
            statement.setString("pTipoColegioqueProviene",Estudiante.getStrTipoColegioqueProvieneEstudiante());
            statement.setString("pTipoBachillerato",Estudiante.getStrTipoBachilleratoEstudiante());
            statement.setDate("pFechaInicio",new java.sql.Date(Estudiante.getStrFechaInicioEstudiante().getTime()));
            statement.setDate("pFechaMatricula",new java.sql.Date(Estudiante.getStrFechaMatriculaEstudiante().getTime()));
            statement.setString("pPeriodo",Estudiante.getStrPeriodoEstudiante());
            statement.setString("pTipoMatricula",Estudiante.getStrTipoMatriculaEstudiante());
            statement.setString("pNombreCarrera",Estudiante.getStrNombreCarreraEstudiante());
            statement.setString("pTituloqueOtorga",Estudiante.getStrTituloqueOtorgaEstudiante());
            statement.setString("pTipoCarrera",Estudiante.getStrTipoCarreraEstudiante());
            statement.setString("pModalidad",Estudiante.getStrModalidadEstudiante());
            statement.setString("pJornada",Estudiante.getStrJornadaEstudiante());
            statement.setString("pEtnias_idEtnias",Estudiante.getStrEtnias_idEtnias());
            statement.setString("pingresocarrera_idingresocarrera",Estudiante.getStringresocarrera_idingresocarrera());
           

            JOptionPane.showMessageDialog(null,"¡Estudiante Actualizado con éxito!","Mensaje del Sistema",1);           

        }catch(SQLException ex){
            ex.printStackTrace();
        }
        
    }    
    
    public ArrayList<ClsEntidadEstudiante> listarEstudiantes(){
        ArrayList<ClsEntidadEstudiante>  Estudianteestudiante=new ArrayList<ClsEntidadEstudiante>();
        try{
            CallableStatement statement=connection.prepareCall("{call SP_S_Ingresoestudiantes}");
            ResultSet resultSet=statement.executeQuery();
            
            while (resultSet.next()){
                ClsEntidadEstudiante estudiante=new ClsEntidadEstudiante();
                estudiante.setStridingresoestudiante(resultSet.getString("idingresoestudiantes"));
                estudiante.setStrNombresEstudiante(resultSet.getString("Nombres"));
                estudiante.setStrApellidosEstudiante(resultSet.getString("Apellidos"));
                estudiante.setStrCedulaEstudiante(resultSet.getString("Cedula"));
                estudiante.setStrCorreoEstudiante(resultSet.getString("Correo"));
                estudiante.setStrNroCelularEstudiante(resultSet.getString("NroCelular"));
                estudiante.setStrDireccionEstudiante(resultSet.getString("Direccion"));
                estudiante.setStrNombreContactoEmergenciaEstudiante(resultSet.getString("NombreContactoEmergencia"));
                estudiante.setStrNroContactoEmergenciaEstudiante(resultSet.getString("NroContactoEmergencia"));
                estudiante.setStrFechaNacimientoEstudiante(resultSet.getDate("FechaNacimiento"));
                estudiante.setStrEdadEstudiante(resultSet.getString("Edad"));
                estudiante.setStrNacionalidadEstudiante(resultSet.getString("Nacionalidad"));
                estudiante.setStrEstadoCivilEstudiante(resultSet.getString("EstadoCivil"));
                estudiante.setStrTieneDiscapacidadEstudiante(resultSet.getString("TieneDiscapacidad"));
                estudiante.setStrTipoColegioqueProvieneEstudiante(resultSet.getString("TipoColegioqueProviene"));
                estudiante.setStrTipoBachilleratoEstudiante(resultSet.getString("TipoBachillerato"));
                estudiante.setStrFechaInicioEstudiante(resultSet.getDate("FechaInicio"));
                estudiante.setStrFechaMatriculaEstudiante(resultSet.getDate("FechaMatricula"));
                estudiante.setStrPeriodoEstudiante(resultSet.getString("Periodo"));
                estudiante.setStrTipoMatriculaEstudiante(resultSet.getString("TipoMatricula"));
                estudiante.setStrModalidadEstudiante(resultSet.getString("Modalidad"));
                estudiante.setStrJornadaEstudiante(resultSet.getString("Jornada"));
                estudiante.setStrEtnias_idEtnias(resultSet.getString("Etnias_idEtnias"));
                estudiante.setStringresocarrera_idingresocarrera(resultSet.getString("ingresocarrera_idingresocarrera"));
                 Estudianteestudiante.add(estudiante);
            }
            return  Estudianteestudiante;
         }catch(SQLException ex){
            ex.printStackTrace();
            return null;
        }
    }      
    public ResultSet listarEstudiantePorParametro(String criterio, String busqueda) throws Exception{
        ResultSet rs = null;
        try{
            CallableStatement statement = connection.prepareCall("{call SP_S_IngresoEstudiantesPorParametro(?,?)}");
            statement.setString("pcriterio", criterio);
            statement.setString("pbusqueda", busqueda);
            rs = statement.executeQuery();
            return rs;
        }catch(SQLException SQLex){
            throw SQLex;            
        }        
    }
    
}


