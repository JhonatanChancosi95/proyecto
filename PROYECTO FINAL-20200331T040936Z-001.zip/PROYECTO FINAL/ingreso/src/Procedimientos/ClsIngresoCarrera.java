
package Procedimientos;
import Conexion.*;
import Entidad.*;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class ClsIngresoCarrera {
  private Connection connection=new ClsConexion().getConection();
    //--------------------------------------------------------------------------------------------------
    //-----------------------------------------METODOS--------------------------------------------------
    //-------------------------------------------------------------------------------------------------- 
    public void agregarCarrera(ClsEntidadCarrera Carrera){
        try{
            CallableStatement statement=connection.prepareCall("{call SP_I_Ingresocarrera(?,?,?)}");
            statement.setString("pCodigo",Carrera.getStrCodigoCarrera());
            statement.setString("pNombreCarrera",Carrera.getStrNombreCarrera());
            statement.setString("pCoordinador",Carrera.getStrCoordinadorCarrera());
            statement.execute();

            JOptionPane.showMessageDialog(null,"¡Carrera  Agregado con éxito!","Mensaje del Sistema",1);           

        }catch(SQLException ex){
            ex.printStackTrace();
        }
        
    }    
    public void modificarCarrera(String codigo,ClsEntidadCarrera Carrera){
        try{
            CallableStatement statement=connection.prepareCall("{call SP_U_Ingresocarrera(?,?,?)}");
            statement.setString("pCodigo",Carrera.getStrCodigoCarrera());
            statement.setString("pNombreCarrera",Carrera.getStrNombreCarrera());
            statement.setString("pCoordinador",Carrera.getStrCoordinadorCarrera());
            statement.executeUpdate();
            
        }catch(SQLException ex){
            ex.printStackTrace();
        }
        JOptionPane.showMessageDialog(null,"¡Carrera Actualizado!","Mensaje del Sistema",1);
    }
    public ArrayList<ClsEntidadCarrera> listarCarrera(){
        ArrayList<ClsEntidadCarrera> carrerausuarios=new ArrayList<ClsEntidadCarrera>();
        try{
            CallableStatement statement=connection.prepareCall("{call SP_S_Ingresocarrera}");
            ResultSet resultSet=statement.executeQuery();
            
            while (resultSet.next()){
                ClsEntidadCarrera carrera=new ClsEntidadCarrera();
                carrera.setStridingresocarreraS(resultSet.getString("idingresocarrera"));
                carrera.setStrCodigoCarrera(resultSet.getString("Codigo"));
                carrera.setStrNombreCarrera(resultSet.getString("NombreCarrera"));
                carrera.setStrCoordinadorCarrera(resultSet.getString("Coordinador"));
                carrerausuarios.add(carrera);
            }
            return carrerausuarios;
         }catch(SQLException ex){
            ex.printStackTrace();
            return null;
        }
    }      
    public ResultSet listarCarreraPorParametro(String criterio, String busqueda) throws Exception{
        ResultSet rs = null;
        try{
            CallableStatement statement = connection.prepareCall("{call SP_S_IngresoCarreraPorParametro(?,?)}");
            statement.setString("pcriterio", criterio);
            statement.setString("pbusqueda", busqueda);
            rs = statement.executeQuery();
            return rs;
        }catch(SQLException SQLex){
            throw SQLex;            
        }        
    }
    
}
