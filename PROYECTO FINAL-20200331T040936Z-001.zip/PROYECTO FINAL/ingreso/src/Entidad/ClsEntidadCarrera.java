/*/*sara.nmc
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidad;


public class ClsEntidadCarrera {
    private String stridingresocarreraS;
    private String strCodigoCarrera;
    private String strNombreCarrera;
    private String strCoordinadorCarrera;


    /**
     * @return the stridingresocarreraS
     */
    public String getStridingresocarreraS() {
        return stridingresocarreraS;
    }

    /**
     * @param stridingresocarreraS the stridingresocarreraS to set
     */
    public void setStridingresocarreraS(String stridingresocarreraS) {
        this.stridingresocarreraS = stridingresocarreraS;
    }

    /**
     * @return the strCodigoCarrera
     */
    public String getStrCodigoCarrera() {
        return strCodigoCarrera;
    }

    /**
     * @param strCodigoCarrera the strCodigoCarrera to set
     */
    public void setStrCodigoCarrera(String strCodigoCarrera) {
        this.strCodigoCarrera = strCodigoCarrera;
    }

    /**
     * @return the strNombreCarrera
     */
    public String getStrNombreCarrera() {
        return strNombreCarrera;
    }

    /**
     * @param strNombreCarrera the strNombreCarrera to set
     */
    public void setStrNombreCarrera(String strNombreCarrera) {
        this.strNombreCarrera = strNombreCarrera;
    }

    /**
     * @return the strCoordinadorCarrera
     */
    public String getStrCoordinadorCarrera() {
        return strCoordinadorCarrera;
    }

    /**
     * @param strCoordinadorCarrera the strCoordinadorCarrera to set
     */
    public void setStrCoordinadorCarrera(String strCoordinadorCarrera) {
        this.strCoordinadorCarrera = strCoordinadorCarrera;
    }
}
