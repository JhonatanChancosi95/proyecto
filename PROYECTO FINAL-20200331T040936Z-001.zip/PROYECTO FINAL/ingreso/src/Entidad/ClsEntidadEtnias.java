/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidad;


public class ClsEntidadEtnias {
   private String stridEtnias;
    private String strNombreEtnias;  

    public ClsEntidadEtnias(String stridEtnias, String strNombreEtnias) {
        this.stridEtnias = stridEtnias;
        this.strNombreEtnias = strNombreEtnias;
    }

    /**
     * @return the stridEtnias
     */
    public String getStridEtnias() {
        return stridEtnias;
    }

    /**
     * @param stridEtnias the stridEtnias to set
     */
    public void setStridEtnias(String stridEtnias) {
        this.stridEtnias = stridEtnias;
    }

    /**
     * @return the strNombreEtnias
     */
    public String getStrNombreEtnias() {
        return strNombreEtnias;
    }

    /**
     * @param strNombreEtnias the strNombreEtnias to set
     */
    public void setStrNombreEtnias(String strNombreEtnias) {
        this.strNombreEtnias = strNombreEtnias;
    }
}
