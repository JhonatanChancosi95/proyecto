/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vista;
import Procedimientos.ClsIngresoDocentes;
import Conexion.ClsConexion;
import Entidad.*;
import java.awt.Color;
import java.awt.Component;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
/**
 *
 * @author Usuario
 */
public class ingresoDocente extends javax.swing.JInternalFrame {
    
    private Connection connection=new ClsConexion().getConection();
    String Total;
    String strCodigo;
    String accion;
    int registros;
    String id[]=new String[50];
    static int intContador;
    
    //-----------------------------------------------
    public String codigo;
    static Connection conn=null;
    static ResultSet rs=null;
    DefaultTableModel dtm=new DefaultTableModel();
    String criterio,busqueda;
 DefaultTableModel model;
    String sql="";
    /**
     * Creates new form ingresoDocente
     */
    public ingresoDocente() {
        
        initComponents();
        
        tabDocente.setIconAt(tabDocente.indexOfComponent(pBuscar), new ImageIcon("src/iconos/busca_p1.png"));
        tabDocente .setIconAt(tabDocente.indexOfComponent(pNuevo), new ImageIcon("src/iconos/nuevo1.png"));
        buttonGroup1.add(rbtnidDocente);
        buttonGroup1.add(rbtnNombre);
        buttonGroup1.add(rbtnApellido);
        buttonGroup1.add(rbtnCedula);
        buttonGroup1.add(rbtnCarrera);
        
        mirar();
        ComboCarrera();
//        sqlCarrera();
        actualizarTabla();
        //---------------------ANCHO Y ALTO DEL FORM----------------------
        this.setSize(707, 426);
        CrearTabla();
        CantidadTotal();
    }
     public void ComboCarrera() {
        String sql = "SELECT * FROM ingresodocentes";
        try {
            Conexion.ClsConexion con = new ClsConexion();
            Connection cnn = con.getConection();
            Statement st = cnn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                cmbxCarrera.addItem(rs.getString("ingresodocentes"));
            }
        } catch (Exception e) {
        }
    }
    //-----------------------------------------------------------------------------------------------
//--------------------------------------METODOS--------------------------------------------------
//-----------------------------------------------------------------------------------------------
  void CrearTabla(){
   //--------------------PRESENTACION DE JTABLE----------------------
      
        TableCellRenderer render = new DefaultTableCellRenderer() { 

            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) { 
                //aqui obtengo el render de la calse superior 
                JLabel l = (JLabel)super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column); 
                //Determinar Alineaciones   
                    if(column==0 || column==2 || column==3 || column==5){
                        l.setHorizontalAlignment(SwingConstants.CENTER); 
                    }else{
                        l.setHorizontalAlignment(SwingConstants.LEFT);
                    }

                //Colores en Jtable        
                if (isSelected) {
                    l.setBackground(new Color(203, 159, 41));
                    //l.setBackground(new Color(168, 198, 238));
                    l.setForeground(Color.WHITE); 
                }else{
                    l.setForeground(Color.BLACK);
                    if (row % 2 == 0) {
                        l.setBackground(Color.WHITE);
                    } else {
                        //l.setBackground(new Color(232, 232, 232));
                        l.setBackground(new Color(254, 227, 152));
                    }
                }         
                return l; 
            } 
        }; 
        
        //Agregar Render
        for (int i=0;i<tblDocente.getColumnCount();i++){
            tblDocente.getColumnModel().getColumn(i).setCellRenderer(render);
        }
      
        //Activar ScrollBar
        tblDocente.setAutoResizeMode(tblDocente.AUTO_RESIZE_OFF);

        //Anchos de cada columna
        int[] anchos = {50,200,80,80,150,80,200};
        for(int i = 0; i < tblDocente.getColumnCount(); i++) {
            tblDocente.getColumnModel().getColumn(i).setPreferredWidth(anchos[i]);
        }
    }
   void CantidadTotal(){
       Total= String.valueOf(tblDocente.getRowCount());   
//       lblEstado.setText("Se cargaron " + Total + " registros");      
   }
   void limpiarCampos(){
       txtidDocente.setText("");
       txtNombre.setText("");
       txtApellido.setText("");
       txtCedula.setText("");
       cmbxCarrera.setSelectedItem(0);
       
       rbtnidDocente.setSelected(false);
       rbtnNombre.setSelected(false);
       rbtnApellido.setSelected(false);
       rbtnCedula.setSelected(false);
       rbtnCarrera.setSelected(false);
       txtBusqueda.setText("");
   }
       
   void mirar(){
       tblDocente.setEnabled(true);
       btnNuevo.setEnabled(true);
       btnModificar.setEnabled(true);
       btnGuardar.setEnabled(false);
       btnCancelar.setEnabled(false);
       btnSalir.setEnabled(true);
        
       txtNombre.setEnabled(false);
       txtApellido.setEnabled(false);
       txtCedula.setEnabled(false); 
       cmbxCarrera.setEnabled(false);
   }
   
   void modificar(){
       tblDocente.setEnabled(false);
       btnNuevo.setEnabled(false);
       btnModificar.setEnabled(false);
       btnGuardar.setEnabled(true);
       btnCancelar.setEnabled(true);
       btnSalir.setEnabled(false);
        
       txtNombre.setEnabled(true);
       txtApellido.setEnabled(true);
       txtCedula.setEnabled(true);
       txtNombre.setEnabled(true);
       cmbxCarrera.setEnabled(true);
   }
//   String sql = "";
//    DefaultTableModel model;
//    ClsConexion con = new ClsConexion();
//    Connection cn = con.getConection();
//    Statement st;
////    ResultSet rs;
//
//    public void sqlCarrera() {
//        sql = "SELECT * FROM ingresodocentes WHERE idingresodocentes= CarreraquePertenece;";
//        cargar(sql);
//    }
//    
//    void cargar(String valor) {
//        String[] titulos = {"idingresodocentes", "Nombre", "Apellido", "Cedula", "CarreraquePertenece"};
//        String[] registros = new String[5];
//
//        String sql = valor;
//        model = new DefaultTableModel(null, titulos);
//
//        try {
//            st = cn.createStatement();
//            rs = st.executeQuery(sql);
//            //Object[] regustros = new Object[rs.getColumnCount()];
//            while (rs.next()) {
//                registros[0] = rs.getString("idingresodocentes");
//                registros[1] = rs.getString("Nombre");
//                registros[2] = rs.getString("Apellido");
//                registros[3] = rs.getString("Cedula");
//                registros[4] = rs.getString("CarreraquePertenece");
//                
//                model.addRow(registros);
//                tblDocente.setModel(model);
//            }
//        } catch (SQLException ex) {
//            //Logger.getLogger(JIFPersonalInterno.class.getName()).log(Level.SEVERE, null, ex);
//            JOptionPane.showMessageDialog(null, ex, "Error de excepción", JOptionPane.ERROR_MESSAGE);
//        }
//    }

   
    void actualizarTabla(){
       String titulos[]={"idingresodocentes","Nombre ","Apellido","Cedula","CarreraquePertenece"};
              
       ClsIngresoDocentes docentes=new ClsIngresoDocentes();
       ArrayList<ClsEntidadDocente> docente=docentes.listarDocente();
       Iterator iterator=docente.iterator();
       DefaultTableModel defaultTableModel=new DefaultTableModel(null,titulos);
       
       String fila[]=new String[5];
       while(iterator.hasNext()){
           ClsEntidadDocente Docente=new ClsEntidadDocente();
           Docente=(ClsEntidadDocente) iterator.next();
           fila[0]=Docente.getStridingresodocentes();
           fila[1]=Docente.getStrNombreDocente();       
           fila[2]=Docente.getStrApellidoDocente();
           fila[3]=Docente.getStrCedulaDocente();
           fila[4]=Docente.getStrCarreraquePertenece();
           defaultTableModel.addRow(fila);               
       }
       tblDocente.setModel(defaultTableModel);
   }
   void BuscarDocente(){
        String titulos[]={"idingresodocentes","Nombre","Apellido","Cedula","CarreraquePertenece"};
        dtm.setColumnIdentifiers(titulos);
        
        ClsIngresoDocentes categoria=new ClsIngresoDocentes();
        busqueda=txtBusqueda.getText();
        if(rbtnidDocente.isSelected()){
            criterio="idingresodocentes";
        }else if(rbtnNombre.isSelected()){
            criterio="Nombre";
        }else if(rbtnApellido.isSelected()){
            criterio="Apellido";
        }else if(rbtnCedula.isSelected()){
            criterio="Cedula";
            }else if(rbtnCarrera.isSelected()){
            criterio="CarreraquePertenece";
           
        }
        try{
            rs=categoria.listarDocentePorParametro(criterio,busqueda);
            boolean encuentra=false;
            String Datos[]=new String[5];
            int f,i;
            f=dtm.getRowCount();
            if(f>0){
                for(i=0;i<f;i++){
                    dtm.removeRow(0);
                }
            }
            while(rs.next()){
                Datos[0]=(String) rs.getString(1);
                Datos[1]=(String) rs.getString(2);
                Datos[2]=(String) rs.getString(3);
                Datos[3]=(String) rs.getString(4);
                Datos[4]=(String) rs.getString(5);

                dtm.addRow(Datos);
                encuentra=true;

            }
            if(encuentra=false){
                JOptionPane.showMessageDialog(null, "¡No se encuentra!");
            }

        }catch(Exception ex){
            ex.printStackTrace();
        }
        tblDocente.setModel(dtm);
    }
    void listardatos(){
        String estado;
        DefaultTableModel defaultTableModel=new DefaultTableModel();
        if(registros==-1){
            JOptionPane.showMessageDialog(null,"Se debe seleccionar un registro");
        }else{
            defaultTableModel=(DefaultTableModel) tblDocente.getModel();
            strCodigo=((String) defaultTableModel.getValueAt(registros,0));
            txtidDocente.setText((String)defaultTableModel.getValueAt(registros,0));
            txtNombre.setText((String)defaultTableModel.getValueAt(registros,1));
            txtApellido.setText((String)defaultTableModel.getValueAt(registros,2));
            txtCedula.setText((String)defaultTableModel.getValueAt(registros,3));
            cmbxCarrera.setSelectedItem((String)defaultTableModel.getValueAt(registros,4));
            tblDocente.setRowSelectionInterval(registros,registros);
        }
    
    
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jLabel12 = new javax.swing.JLabel();
        btnNuevo = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();
        tabDocente = new javax.swing.JTabbedPane();
        pBuscar = new javax.swing.JPanel();
        rbtnidDocente = new javax.swing.JRadioButton();
        rbtnNombre = new javax.swing.JRadioButton();
        rbtnApellido = new javax.swing.JRadioButton();
        rbtnCedula = new javax.swing.JRadioButton();
        rbtnCarrera = new javax.swing.JRadioButton();
        lblBusqueda = new javax.swing.JLabel();
        txtBusqueda = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblDocente = new javax.swing.JTable();
        pNuevo = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        cmbxCarrera = new javax.swing.JComboBox<>();
        txtNombre = new javax.swing.JTextField();
        txtCedula = new javax.swing.JTextField();
        txtidDocente = new javax.swing.JTextField();
        txtApellido = new javax.swing.JTextField();

        setBackground(new java.awt.Color(153, 153, 153));
        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);

        jLabel12.setText("Mantenimiento");
        jLabel12.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jLabel12.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        btnNuevo.setText("Nuevo");
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });

        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        btnModificar.setText("Modificar");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        btnCancelar.setText("Cancelar");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        btnSalir.setText("Salir");
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });

        pBuscar.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        rbtnidDocente.setText("ID Ingreso Docente");
        rbtnidDocente.setOpaque(false);
        rbtnidDocente.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                rbtnidDocenteStateChanged(evt);
            }
        });
        rbtnidDocente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnidDocenteActionPerformed(evt);
            }
        });
        pBuscar.add(rbtnidDocente, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, -1, -1));

        rbtnNombre.setText("Nombres");
        rbtnNombre.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                rbtnNombreStateChanged(evt);
            }
        });
        pBuscar.add(rbtnNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 40, -1, -1));

        rbtnApellido.setText("Apellidos");
        pBuscar.add(rbtnApellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 40, -1, -1));

        rbtnCedula.setText("Nº de cedula");
        pBuscar.add(rbtnCedula, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 40, -1, -1));

        rbtnCarrera.setText("Carrera");
        pBuscar.add(rbtnCarrera, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 40, -1, -1));

        lblBusqueda.setBackground(new java.awt.Color(153, 255, 153));
        lblBusqueda.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lblBusqueda.setText("Criterios de busqueda");
        lblBusqueda.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        lblBusqueda.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        pBuscar.add(lblBusqueda, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 480, 70));

        txtBusqueda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtBusquedaActionPerformed(evt);
            }
        });
        txtBusqueda.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBusquedaKeyReleased(evt);
            }
        });
        pBuscar.add(txtBusqueda, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 300, 30));

        jScrollPane1.setBackground(new java.awt.Color(153, 153, 153));

        tblDocente.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblDocente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblDocenteMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblDocente);

        pBuscar.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 131, 470, 100));

        tabDocente.addTab("Buscar", pBuscar);

        jLabel6.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jLabel6.setText("idingresodocentes");

        jLabel7.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jLabel7.setText("NOMBRES");

        jLabel2.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jLabel2.setText("APELLIDOS");

        jLabel4.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jLabel4.setText(" N° CEDULA");

        jLabel3.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jLabel3.setText("CARRERA ALA QUE PERTENECE");

        cmbxCarrera.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "DESARROLLO DE SOFTWARE", "ADMINISTRACION", "DISEÑO GRAFICO REDISEÑADA", "ANALISIS DE SISTEMAS", "ADMINISTRACION DE EMPRESAS", "DISEÑO GRAFICO ANTIGUA" }));
        cmbxCarrera.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbxCarreraActionPerformed(evt);
            }
        });

        txtCedula.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCedulaActionPerformed(evt);
            }
        });
        txtCedula.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtCedulaKeyReleased(evt);
            }
        });

        txtidDocente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtidDocenteActionPerformed(evt);
            }
        });

        txtApellido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtApellidoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pNuevoLayout = new javax.swing.GroupLayout(pNuevo);
        pNuevo.setLayout(pNuevoLayout);
        pNuevoLayout.setHorizontalGroup(
            pNuevoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pNuevoLayout.createSequentialGroup()
                .addGroup(pNuevoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(pNuevoLayout.createSequentialGroup()
                        .addGroup(pNuevoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(70, 70, 70)
                        .addGroup(pNuevoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtidDocente, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtCedula, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtNombre, javax.swing.GroupLayout.DEFAULT_SIZE, 241, Short.MAX_VALUE)
                            .addComponent(txtApellido)))
                    .addGroup(pNuevoLayout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmbxCarrera, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(56, Short.MAX_VALUE))
        );
        pNuevoLayout.setVerticalGroup(
            pNuevoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pNuevoLayout.createSequentialGroup()
                .addGroup(pNuevoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pNuevoLayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel6))
                    .addGroup(pNuevoLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(txtidDocente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(13, 13, 13)
                .addGroup(pNuevoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtCedula, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(pNuevoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addGroup(pNuevoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtApellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(pNuevoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(cmbxCarrera, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(126, 126, 126))
        );

        tabDocente.addTab("Nuevo/Modificar", pNuevo);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(tabDocente, javax.swing.GroupLayout.PREFERRED_SIZE, 480, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(btnNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(btnModificar, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(btnCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(btnSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tabDocente, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel12)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(16, 16, 16)
                                .addComponent(btnNuevo)
                                .addGap(47, 47, 47)
                                .addComponent(btnModificar)
                                .addGap(12, 12, 12)
                                .addComponent(btnCancelar))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(46, 46, 46)
                                .addComponent(btnGuardar))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(156, 156, 156)
                                .addComponent(btnSalir))))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed

         accion="Nuevo";
        modificar();
        limpiarCampos();
        tblDocente.setEnabled(false);
        tabDocente.setSelectedIndex(tabDocente.indexOfComponent(pNuevo));
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
 if(validardatos()==true){  
            if(accion.equals("Nuevo")){
                ClsIngresoDocentes docentes=new ClsIngresoDocentes();
                ClsEntidadDocente docente=new ClsEntidadDocente();
                docente.setStrNombreDocente(txtNombre.getText());
                docente.setStrApellidoDocente(txtApellido.getText());
                docente.setStrCedulaDocente(txtCedula.getText());
                docentes.agregarDocente(docente);
                actualizarTabla();
                CantidadTotal();
            }
            if(accion.equals("Modificar")){
                ClsIngresoDocentes docentes=new ClsIngresoDocentes();
                ClsEntidadDocente docente=new ClsEntidadDocente();
                docente.setStrNombreDocente(txtNombre.getText());
                docente.setStrApellidoDocente(txtApellido.getText());
                docente.setStrCedulaDocente(txtCedula.getText());
                docentes.modificarDocente(strCodigo, docente);
                actualizarTabla();
                limpiarCampos();
                modificar();
                CantidadTotal();
            }
            CrearTabla();
            mirar();
            tabDocente.setSelectedIndex(tabDocente.indexOfComponent(pBuscar)); 
        }
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
if(tblDocente.getSelectedRows().length > 0 ) { 
        accion="Modificar";
        modificar();
        tabDocente.setSelectedIndex(tabDocente.indexOfComponent(pNuevo));
        }else{
            JOptionPane.showMessageDialog(null, "¡Se debe seleccionar un registro!");
        } 
    }//GEN-LAST:event_btnModificarActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
 mirar();
        tabDocente.setSelectedIndex(tabDocente.indexOfComponent(pBuscar));
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_btnSalirActionPerformed

    private void rbtnidDocenteStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_rbtnidDocenteStateChanged

    }//GEN-LAST:event_rbtnidDocenteStateChanged

    private void rbtnidDocenteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnidDocenteActionPerformed

    }//GEN-LAST:event_rbtnidDocenteActionPerformed

    private void rbtnNombreStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_rbtnNombreStateChanged

    }//GEN-LAST:event_rbtnNombreStateChanged

    private void txtBusquedaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtBusquedaActionPerformed

    }//GEN-LAST:event_txtBusquedaActionPerformed

    private void txtBusquedaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBusquedaKeyReleased
// if(rbtnidDocente.isSelected()){
//            sql="SELECT *  FROM acceso WHERE Usuario LIKE '%"+txtBuscar.getText()+"%'";
//            cargar(sql);
//        }else if(rbBuscarApellido.isSelected()){
//            sql="SELECT *  FROM acceso WHERE Contraseña LIKE '%"+txtBuscar.getText()+"%'";
//            cargar(sql);
//        }else if(rbBuscarTelefono.isSelected()){
//            sql="SELECT * FROM acceso WHERE cargo LIKE '%"+txtBuscar.getText()+"%'";
//            cargar(sql);
//        }             
    }//GEN-LAST:event_txtBusquedaKeyReleased

    private void cmbxCarreraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbxCarreraActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbxCarreraActionPerformed

    private void txtCedulaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCedulaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCedulaActionPerformed

    private void txtApellidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtApellidoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtApellidoActionPerformed

    private void txtidDocenteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtidDocenteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtidDocenteActionPerformed

    private void txtCedulaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCedulaKeyReleased
        // TODO add your handling code here:
         String cadena= (txtNombre.getText()).toUpperCase();
        txtNombre.setText(cadena);
        int keyCode = evt.getKeyCode();
        if (keyCode==KeyEvent.VK_ENTER) txtCedula.requestFocus();
    }//GEN-LAST:event_txtCedulaKeyReleased

    private void tblDocenteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblDocenteMouseClicked
        // TODO add your handling code here:
        int fila;
        DefaultTableModel defaultTableModel = new DefaultTableModel();
        fila = tblDocente.getSelectedRow();

        if (fila == -1){
            JOptionPane.showMessageDialog(null, "Se debe seleccionar un registro");
        }else{
            defaultTableModel = (DefaultTableModel)tblDocente.getModel();
            strCodigo =  ((String) defaultTableModel.getValueAt(fila, 0));
            txtidDocente.setText((String) defaultTableModel.getValueAt(fila, 0));
            txtNombre.setText((String) defaultTableModel.getValueAt(fila, 1));
            txtApellido.setText((String)defaultTableModel.getValueAt(fila,2));
            txtCedula.setText((String)defaultTableModel.getValueAt(fila,3));
            
        }
        mirar();
    }//GEN-LAST:event_tblDocenteMouseClicked
//----------------------VALIDACIÓN DE DATOS-------------------------------------
    public boolean validardatos(){
        if (txtNombre.getText().equals("")){
            JOptionPane.showMessageDialog(null, "Ingrese nombre ");
            txtNombre.requestFocus();
            txtNombre.setBackground(Color.YELLOW);
            return false;

        }else{
            return true;
        }

    }                                                

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JButton btnSalir;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<String> cmbxCarrera;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblBusqueda;
    private javax.swing.JPanel pBuscar;
    private javax.swing.JPanel pNuevo;
    private javax.swing.JRadioButton rbtnApellido;
    private javax.swing.JRadioButton rbtnCarrera;
    private javax.swing.JRadioButton rbtnCedula;
    private javax.swing.JRadioButton rbtnNombre;
    private javax.swing.JRadioButton rbtnidDocente;
    private javax.swing.JTabbedPane tabDocente;
    private javax.swing.JTable tblDocente;
    private javax.swing.JTextField txtApellido;
    private javax.swing.JTextField txtBusqueda;
    private javax.swing.JTextField txtCedula;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtidDocente;
    // End of variables declaration//GEN-END:variables
}
