/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;
import Procedimientos.ClsIngresoDocentes;
import Conexion.ClsConexion;
import Entidad.*;
import Procedimientos.ClsIngresoCarrera;
import java.awt.Color;
import java.awt.Component;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
/**
 *
 * @author Usuario
 */
public class ingresoCarrera extends javax.swing.JInternalFrame {
    
    private Connection connection=new ClsConexion().getConection();
    String Total;
    String strCodigo;
    String accion;
    int registros;
    String id[]=new String[50];
    static int intContador;
    
    //-----------------------------------------------
    public String codigo;
    static Connection conn=null;
    static ResultSet rs=null;
    DefaultTableModel dtm=new DefaultTableModel();
    String criterio,busqueda;

    /**
     * Creates new form ingresoDocente
     */
    public ingresoCarrera() {
        initComponents();
        
        tabCarrera.setIconAt(tabCarrera.indexOfComponent(pBuscar), new ImageIcon("src/iconos/busca_p1.png"));
        tabCarrera .setIconAt(tabCarrera.indexOfComponent(pNuevo), new ImageIcon("src/iconos/nuevo1.png"));
        buttonGroup1.add(rbtnidCarrera);
        buttonGroup1.add(rbtnCodigo);
        buttonGroup1.add(rbtnNombre);
        buttonGroup1.add(rbtnCoordinador);
        
        
        mirar();
        actualizarTabla();
        //---------------------ANCHO Y ALTO DEL FORM----------------------
        this.setSize(707, 426);
        CrearTabla();
        CantidadTotal();
    }
    
    //-----------------------------------------------------------------------------------------------
//--------------------------------------METODOS--------------------------------------------------
//-----------------------------------------------------------------------------------------------
  void CrearTabla(){
   //--------------------PRESENTACION DE JTABLE----------------------
      
        TableCellRenderer render = new DefaultTableCellRenderer() { 

            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) { 
                //aqui obtengo el render de la calse superior 
                JLabel l = (JLabel)super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column); 
                //Determinar Alineaciones   
                    if(column==0 || column==2 || column==3 || column==5){
                        l.setHorizontalAlignment(SwingConstants.CENTER); 
                    }else{
                        l.setHorizontalAlignment(SwingConstants.LEFT);
                    }

                //Colores en Jtable        
                if (isSelected) {
                    l.setBackground(new Color(203, 159, 41));
                    //l.setBackground(new Color(168, 198, 238));
                    l.setForeground(Color.WHITE); 
                }else{
                    l.setForeground(Color.BLACK);
                    if (row % 2 == 0) {
                        l.setBackground(Color.WHITE);
                    } else {
                        //l.setBackground(new Color(232, 232, 232));
                        l.setBackground(new Color(254, 227, 152));
                    }
                }         
                return l; 
            } 
        }; 
        
        //Agregar Render
        for (int i=0;i<tblCarrera.getColumnCount();i++){
            tblCarrera.getColumnModel().getColumn(i).setCellRenderer(render);
        }
      
        //Activar ScrollBar
        tblCarrera.setAutoResizeMode(tblCarrera.AUTO_RESIZE_OFF);

        //Anchos de cada columna
        int[] anchos = {50,200,80,80,150,80,200};
        for(int i = 0; i < tblCarrera.getColumnCount(); i++) {
            tblCarrera.getColumnModel().getColumn(i).setPreferredWidth(anchos[i]);
        }
    }
   void CantidadTotal(){
       Total= String.valueOf(tblCarrera.getRowCount());   
//       lblEstado.setText("Se cargaron " + Total + " registros");      
   }
   void limpiarCampos(){
       txtidCarrera.setText("");
       txtNombreCarrera.setText("");
       txtCoordinador.setText("");
       txtCodigo.setText("");
      
       
       rbtnidCarrera.setSelected(false);
       rbtnCodigo.setSelected(false);
       rbtnNombre.setSelected(false);
       rbtnCoordinador.setSelected(false);
       txtBusqueda.setText("");
   }
       
   void mirar(){
       tblCarrera.setEnabled(true);
       btnNuevo.setEnabled(true);
       btnModificar.setEnabled(true);
       btnGuardar.setEnabled(false);
       btnCancelar.setEnabled(false);
       btnSalir.setEnabled(true);
        
       txtNombreCarrera.setEnabled(false);
       txtCoordinador.setEnabled(false);
       txtCodigo.setEnabled(false); 
       
   }
   
   void modificar(){
       tblCarrera.setEnabled(false);
       btnNuevo.setEnabled(false);
       btnModificar.setEnabled(false);
       btnGuardar.setEnabled(true);
       btnCancelar.setEnabled(true);
       btnSalir.setEnabled(false);
        
       txtNombreCarrera.setEnabled(true);
       txtCoordinador.setEnabled(true);
       txtCodigo.setEnabled(true);
       txtNombreCarrera.setEnabled(true);
       
   }
   
   
    void actualizarTabla(){
       String titulos[]={"idingresocarrera","Codigo ","NombreCarrera","Coordinador"};
              
        ClsIngresoCarrera carreras=new ClsIngresoCarrera();
       ArrayList<ClsEntidadCarrera> docente=carreras.listarCarrera();
       Iterator iterator=docente.iterator();
       DefaultTableModel defaultTableModel=new DefaultTableModel(null,titulos);
       
       String fila[]=new String[4];
       while(iterator.hasNext()){
           ClsEntidadCarrera Carrera=new ClsEntidadCarrera();
           Carrera=(ClsEntidadCarrera) iterator.next();
           fila[0]=Carrera.getStridingresocarreraS();
           fila[1]=Carrera.getStrCodigoCarrera();       
           fila[2]=Carrera.getStrNombreCarrera();
           fila[3]=Carrera.getStrCoordinadorCarrera();
          
           defaultTableModel.addRow(fila);               
       }
       tblCarrera.setModel(defaultTableModel);
   }
   void BuscarCarrera(){
        String titulos[]={"idingresocarrera","Codigo ","NombreCarrera","Coordinador"};
        dtm.setColumnIdentifiers(titulos);
        
        ClsIngresoCarrera categoria=new ClsIngresoCarrera();
        busqueda=txtBusqueda.getText();
        if(rbtnidCarrera.isSelected()){
            criterio="idingresocarrera";
        }else if(rbtnCodigo.isSelected()){
            criterio="Codigo";
        }else if(rbtnNombre.isSelected()){
            criterio="NombreCarrera";
        }else if(rbtnCoordinador.isSelected()){
            criterio="Coordinador";
           
           
        }
        try{
            rs=categoria.listarCarreraPorParametro(criterio,busqueda);
            boolean encuentra=false;
            String Datos[]=new String[4];
            int f,i;
            f=dtm.getRowCount();
            if(f>0){
                for(i=0;i<f;i++){
                    dtm.removeRow(0);
                }
            }
            while(rs.next()){
                Datos[0]=(String) rs.getString(1);
                Datos[1]=(String) rs.getString(2);
                Datos[2]=(String) rs.getString(3);
                Datos[3]=(String) rs.getString(4);

                dtm.addRow(Datos);
                encuentra=true;

            }
            if(encuentra=false){
                JOptionPane.showMessageDialog(null, "¡No se encuentra!");
            }

        }catch(Exception ex){
            ex.printStackTrace();
        }
        tblCarrera.setModel(dtm);
    }
    void listardatos(){
        String estado;
        DefaultTableModel defaultTableModel=new DefaultTableModel();
        if(registros==-1){
            JOptionPane.showMessageDialog(null,"Se debe seleccionar un registro");
        }else{
            defaultTableModel=(DefaultTableModel) tblCarrera.getModel();
            strCodigo=((String) defaultTableModel.getValueAt(registros,0));
            txtidCarrera.setText((String)defaultTableModel.getValueAt(registros,0));
            txtCodigo.setText((String)defaultTableModel.getValueAt(registros,1));
            txtNombreCarrera.setText((String)defaultTableModel.getValueAt(registros,2));
            txtCoordinador.setText((String)defaultTableModel.getValueAt(registros,3));
            tblCarrera.setRowSelectionInterval(registros,registros);
        }
    
    
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jLabel12 = new javax.swing.JLabel();
        btnNuevo = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();
        tabCarrera = new javax.swing.JTabbedPane();
        pBuscar = new javax.swing.JPanel();
        rbtnidCarrera = new javax.swing.JRadioButton();
        rbtnCodigo = new javax.swing.JRadioButton();
        rbtnNombre = new javax.swing.JRadioButton();
        rbtnCoordinador = new javax.swing.JRadioButton();
        lblBusqueda = new javax.swing.JLabel();
        txtBusqueda = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblCarrera = new javax.swing.JTable();
        pNuevo = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtNombreCarrera = new javax.swing.JTextField();
        txtCodigo = new javax.swing.JTextField();
        txtidCarrera = new javax.swing.JTextField();
        txtCoordinador = new javax.swing.JTextField();

        setBackground(new java.awt.Color(153, 153, 153));
        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);

        jLabel12.setText("Mantenimiento");
        jLabel12.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jLabel12.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        btnNuevo.setText("Nuevo");
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });

        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        btnModificar.setText("Modificar");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        btnCancelar.setText("Cancelar");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        btnSalir.setText("Salir");
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });

        pBuscar.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        rbtnidCarrera.setText("ID Ingreso Carrera");
        rbtnidCarrera.setOpaque(false);
        rbtnidCarrera.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                rbtnidCarreraStateChanged(evt);
            }
        });
        rbtnidCarrera.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnidCarreraActionPerformed(evt);
            }
        });
        pBuscar.add(rbtnidCarrera, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, -1, -1));

        rbtnCodigo.setText("Codigo");
        rbtnCodigo.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                rbtnCodigoStateChanged(evt);
            }
        });
        pBuscar.add(rbtnCodigo, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 40, -1, -1));

        rbtnNombre.setText("Nombre");
        rbtnNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnNombreActionPerformed(evt);
            }
        });
        pBuscar.add(rbtnNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 40, -1, -1));

        rbtnCoordinador.setText("Coordinador");
        pBuscar.add(rbtnCoordinador, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 40, -1, -1));

        lblBusqueda.setBackground(new java.awt.Color(153, 255, 153));
        lblBusqueda.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lblBusqueda.setText("Criterios de busqueda");
        lblBusqueda.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        lblBusqueda.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        pBuscar.add(lblBusqueda, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 500, 125));

        txtBusqueda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtBusquedaActionPerformed(evt);
            }
        });
        txtBusqueda.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBusquedaKeyReleased(evt);
            }
        });
        pBuscar.add(txtBusqueda, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 300, 30));

        jScrollPane1.setBackground(new java.awt.Color(153, 153, 153));

        tblCarrera.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblCarrera.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblCarreraMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblCarrera);

        pBuscar.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 131, 470, 100));

        tabCarrera.addTab("Buscar", pBuscar);

        jLabel6.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jLabel6.setText("id_IngresoCarrera");

        jLabel7.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jLabel7.setText("NOMBRE CARRERA");

        jLabel2.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jLabel2.setText("COORDINADOR");

        jLabel4.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jLabel4.setText("CODIGO");

        txtCodigo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCodigoActionPerformed(evt);
            }
        });
        txtCodigo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtCodigoKeyReleased(evt);
            }
        });

        txtidCarrera.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtidCarreraActionPerformed(evt);
            }
        });

        txtCoordinador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCoordinadorActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pNuevoLayout = new javax.swing.GroupLayout(pNuevo);
        pNuevo.setLayout(pNuevoLayout);
        pNuevoLayout.setHorizontalGroup(
            pNuevoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pNuevoLayout.createSequentialGroup()
                .addGroup(pNuevoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(24, 24, 24)
                .addGroup(pNuevoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtidCarrera, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNombreCarrera, javax.swing.GroupLayout.DEFAULT_SIZE, 241, Short.MAX_VALUE)
                    .addComponent(txtCoordinador))
                .addContainerGap(74, Short.MAX_VALUE))
        );
        pNuevoLayout.setVerticalGroup(
            pNuevoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pNuevoLayout.createSequentialGroup()
                .addGroup(pNuevoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pNuevoLayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel6))
                    .addGroup(pNuevoLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(txtidCarrera, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(13, 13, 13)
                .addGroup(pNuevoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(pNuevoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txtNombreCarrera, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addGroup(pNuevoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtCoordinador, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(156, 156, 156))
        );

        tabCarrera.addTab("Nuevo/Modificar", pNuevo);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(tabCarrera, javax.swing.GroupLayout.PREFERRED_SIZE, 480, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(btnNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(btnModificar, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(btnCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(btnSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tabCarrera, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel12)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(16, 16, 16)
                                .addComponent(btnNuevo)
                                .addGap(47, 47, 47)
                                .addComponent(btnModificar)
                                .addGap(12, 12, 12)
                                .addComponent(btnCancelar))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(46, 46, 46)
                                .addComponent(btnGuardar))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(156, 156, 156)
                                .addComponent(btnSalir))))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed

         accion="Nuevo";
        modificar();
        limpiarCampos();
        tblCarrera.setEnabled(false);
        tabCarrera.setSelectedIndex(tabCarrera.indexOfComponent(pNuevo));
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
 if(validardatos()==true){  
            if(accion.equals("Nuevo")){
                ClsIngresoCarrera carreras=new ClsIngresoCarrera();
                ClsEntidadCarrera carrera=new ClsEntidadCarrera();
                carrera.setStrCodigoCarrera(txtCodigo.getText());
                carrera.setStrNombreCarrera(txtNombreCarrera.getText());
                carrera.setStrCoordinadorCarrera(txtCoordinador.getText());
                carreras.agregarCarrera(carrera);
                actualizarTabla();
                CantidadTotal();
            }
            if(accion.equals("Modificar")){
                ClsIngresoCarrera carreras=new ClsIngresoCarrera();
                ClsEntidadCarrera carrera=new ClsEntidadCarrera();
                carrera.setStrCodigoCarrera(txtCodigo.getText());
                carrera.setStrNombreCarrera(txtNombreCarrera.getText());
                carrera.setStrCoordinadorCarrera(txtCoordinador.getText());
                carreras.modificarCarrera(strCodigo, carrera);
                actualizarTabla();
                limpiarCampos();
                modificar();
                CantidadTotal();
            }
            CrearTabla();
            mirar();
            tabCarrera.setSelectedIndex(tabCarrera.indexOfComponent(pBuscar)); 
        }
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
if(tblCarrera.getSelectedRows().length > 0 ) { 
        accion="Modificar";
        modificar();
        tabCarrera.setSelectedIndex(tabCarrera.indexOfComponent(pNuevo));
        }else{
            JOptionPane.showMessageDialog(null, "¡Se debe seleccionar un registro!");
        } 
    }//GEN-LAST:event_btnModificarActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
 mirar();
        tabCarrera.setSelectedIndex(tabCarrera.indexOfComponent(pBuscar));
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_btnSalirActionPerformed

    private void rbtnidCarreraStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_rbtnidCarreraStateChanged

    }//GEN-LAST:event_rbtnidCarreraStateChanged

    private void rbtnidCarreraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnidCarreraActionPerformed

    }//GEN-LAST:event_rbtnidCarreraActionPerformed

    private void rbtnCodigoStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_rbtnCodigoStateChanged

    }//GEN-LAST:event_rbtnCodigoStateChanged

    private void txtBusquedaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtBusquedaActionPerformed

    }//GEN-LAST:event_txtBusquedaActionPerformed

    private void txtBusquedaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBusquedaKeyReleased

    }//GEN-LAST:event_txtBusquedaKeyReleased

    private void txtCodigoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCodigoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodigoActionPerformed

    private void txtCoordinadorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCoordinadorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCoordinadorActionPerformed

    private void txtidCarreraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtidCarreraActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtidCarreraActionPerformed

    private void txtCodigoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCodigoKeyReleased
        // TODO add your handling code here:
         String cadena= (txtNombreCarrera.getText()).toUpperCase();
        txtNombreCarrera.setText(cadena);
        int keyCode = evt.getKeyCode();
        if (keyCode==KeyEvent.VK_ENTER) txtCodigo.requestFocus();
    }//GEN-LAST:event_txtCodigoKeyReleased

    private void tblCarreraMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblCarreraMouseClicked
        // TODO add your handling code here:
        int fila;
        DefaultTableModel defaultTableModel = new DefaultTableModel();
        fila = tblCarrera.getSelectedRow();

        if (fila == -1){
            JOptionPane.showMessageDialog(null, "Se debe seleccionar un registro");
        }else{
            defaultTableModel = (DefaultTableModel)tblCarrera.getModel();
            strCodigo =  ((String) defaultTableModel.getValueAt(fila, 0));
            txtidCarrera.setText((String) defaultTableModel.getValueAt(fila, 0));
            txtCodigo.setText((String) defaultTableModel.getValueAt(fila, 1));
            txtNombreCarrera.setText((String)defaultTableModel.getValueAt(fila,2));
            txtCoordinador.setText((String)defaultTableModel.getValueAt(fila,3));
            
        }
        mirar();
    }//GEN-LAST:event_tblCarreraMouseClicked

    private void rbtnNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rbtnNombreActionPerformed
//----------------------VALIDACIÓN DE DATOS-------------------------------------
    public boolean validardatos(){
        if (txtNombreCarrera.getText().equals("")){
            JOptionPane.showMessageDialog(null, "Ingrese nombre ");
            txtNombreCarrera.requestFocus();
            txtNombreCarrera.setBackground(Color.YELLOW);
            return false;

        }else{
            return true;
        }

    }                                                

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JButton btnSalir;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblBusqueda;
    private javax.swing.JPanel pBuscar;
    private javax.swing.JPanel pNuevo;
    private javax.swing.JRadioButton rbtnCodigo;
    private javax.swing.JRadioButton rbtnCoordinador;
    private javax.swing.JRadioButton rbtnNombre;
    private javax.swing.JRadioButton rbtnidCarrera;
    private javax.swing.JTabbedPane tabCarrera;
    private javax.swing.JTable tblCarrera;
    private javax.swing.JTextField txtBusqueda;
    private javax.swing.JTextField txtCodigo;
    private javax.swing.JTextField txtCoordinador;
    private javax.swing.JTextField txtNombreCarrera;
    private javax.swing.JTextField txtidCarrera;
    // End of variables declaration//GEN-END:variables
}
